package com.ascent.util;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.HashMap;
import com.ascent.bean.*;

import java.util.HashSet;
import java.util.Set;


/**
 * 这个类连接数据服务器来获得数据
 * @author ascent
 * @version 1.0
 */
public class UserDataClient implements ProtocolPort {

	/**
	 * socket引用
	 */
	protected Socket hostSocket;

	/**
	 * 输出流的引用
	 */
	protected ObjectOutputStream outputToServer;

	/**
	 * 输入流的引用
	 */
	protected ObjectInputStream inputFromServer;
	


	
	/**
	 * 默认构造方法
	 */
	public UserDataClient() throws IOException {
		this(ProtocolPort.DEFAULT_HOST, ProtocolPort.DEFAULT_PORT);
	}

	/**
	 * 接受主机名和端口号的构造方法
	 */
	public UserDataClient(String hostName, int port) throws IOException {

		log("连接数据服务器..." + hostName + ":" + port);
		try {
			hostSocket = new Socket(hostName, port);
			outputToServer = new ObjectOutputStream(hostSocket.getOutputStream());
			inputFromServer = new ObjectInputStream(hostSocket.getInputStream());
			log("连接成功.");
		} catch (Exception e) {
			log("连接失败.");
		}
	}

	/**
	 * 返回用户
	 * @return userTable 
	 */
	@SuppressWarnings("unchecked")
	public HashMap<String,User> getUsers() {
		HashMap<String,User> userTable = null;

		try {
			log("发送请求: OP_GET_USERS  ");

			outputToServer.writeInt(ProtocolPort.OP_GET_USERS);
			outputToServer.flush();

			log("接收数据...");
			userTable = (HashMap<String,User>) inputFromServer.readObject();

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userTable;
	}
	


	/**
	 * 关闭当前SocKet
	 */
	public void closeSocKet() {
		try {
			this.hostSocket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 日志方法.
	 * @param msg 打印的日志信息
	 */
	protected void log(Object msg) {
		System.out.println("UserDataClient类: " + msg);
	}

	/**
	 * 注册用户
	 * @param username 用户名
	 * @param password 密码
	 * @return boolean true:注册成功，false:注册失败
	 */
	public boolean addUser(String username, String password) {
		HashMap<String,User> map = this.getUsers();
		if (map.containsKey(username)) {
			return false;
		} else {
			try {
				log("发送请求: OP_ADD_USERS  ");
				outputToServer.writeInt(ProtocolPort.OP_ADD_USERS);
				outputToServer.writeObject(new User(username, password, 0));
				outputToServer.flush();
				log("接收数据...");
				try {  
				    // 读取服务器返回的响应  
				    boolean result = inputFromServer.readBoolean(); // 假设服务器返回的是一个布尔值  
				    if (result) {  
				        return true;
				    } else {  
				        return false;
				    }  
				} catch (IOException e) {  
				    log("接收数据时发生异常: " + e.getMessage());  
				    e.printStackTrace();  
				    return false;
				}
			} catch (IOException e) {
				e.printStackTrace();
				return false;
			}
		}
	}
	
	/**
	 * 重置密码后保存用户
	 * @param username 用户名
	 * @param password 密码
	 * @return boolean true:保存成功，false:保存失败
	 */
	public boolean resetPassword(String username, String password) {
		HashMap<String,User> map = this.getUsers();
		if (map.containsKey(username)) {
			// 如果找到对应的用户名，则修改密码  
	        User user = map.get(username);  
	        user.setPassword(password); // 假设 User 类有 setPassword 方法来设置新密码  
	        try {  
	            log("发送请求: OP_UPDATE_USER_PASSWORD");  
	            outputToServer.writeInt(ProtocolPort.OP_UPDATE_USER_PASSWORD); // 假设有对应的操作码  
	            outputToServer.writeObject(user); // 发送修改后的用户对象  
	            outputToServer.flush();  
	            log("接收数据...");  
	            try {  
				    // 读取服务器返回的响应  
				    boolean result = inputFromServer.readBoolean(); // 假设服务器返回的是一个布尔值  
				    if (result) {  
				        return true;
				    } else {  
				        return false;
				    }  
				} catch (IOException e) {  
				    log("接收数据时发生异常: " + e.getMessage());  
				    e.printStackTrace();  
				    return false;
				}
	        } catch (IOException e) {  
	            e.printStackTrace();  
	        }  
		}
		return false;
	}
	
	/**
	 * 修改用户名后保存用户
	 * @param username 旧户名
	 * @param newUserName 新用户名
	 * @return boolean true:保存成功，false:保存失败
	 */
	public boolean resetUserName(String lastname, String newUserName) {
		HashMap<String,User> map = this.getUsers();
		if (map.containsKey(lastname)) {
			// 如果找到对应的用户名，则修改密码  
	        User user = map.get(lastname);  
	        try {  
	            log("发送请求: OP_UPDATE_USER_PASSWORD");  
	            outputToServer.writeInt(ProtocolPort.OP_UPDATE_USER_NAME); // 假设有对应的操作码  
	            outputToServer.writeObject(user);    
	            outputToServer.writeUTF(newUserName);
	            outputToServer.flush();  
	            log("接收数据...");  
	            try {  
				    // 读取服务器返回的响应  
				    boolean result = inputFromServer.readBoolean(); // 假设服务器返回的是一个布尔值  
				    if (result) {  
				        return true;
				    } else {  
				        return false;
				    }  
				} catch (IOException e) {  
				    log("接收数据时发生异常: " + e.getMessage());  
				    e.printStackTrace();  
				    return false;
				}
	        } catch (IOException e) {  
	            e.printStackTrace();  
	            return false;
	        }  
		} 
		return false;
	}
	
	
	

}

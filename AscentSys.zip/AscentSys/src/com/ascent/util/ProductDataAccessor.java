package com.ascent.util;

import java.util.*;
import java.io.*;
import com.ascent.bean.Product;
import com.ascent.bean.User;


import java.nio.file.*;
import java.util.stream.*;

/**
 * 产品数据读取的实现类
 * @author ascent
 * @version 1.0
 */
public class ProductDataAccessor extends DataAccessor {

	// ////////////////////////////////////////////////////
	//
	// 产品文件格式如下
	// 产品名称,化学文摘登记号,结构图,公式,价格,数量,类别
	// ----------------------------------------------------
	//
	// ////////////////////////////////////////////////////

	// ////////////////////////////////////////////////////
	//
	// 用户文件格式如下
	// 用户帐号,用户密码,用户权限
	// ----------------------------------------------------
	//
	// ////////////////////////////////////////////////////
	/**
	 * 商品信息数据文件名
	 */
	protected static final String PRODUCT_FILE_NAME = "product.db";

	/**
	 * 用户信息数据文件名
	 */
	protected static final String USER_FILE_NAME = "user.db";

	/**
	 * 数据记录的分割符
	 */
	protected static final String RECORD_SEPARATOR = "----------";

	/**
	 * 默认构造方法
	 */
	public ProductDataAccessor() {
		load();
	}

	/**
	 * 读取数据的方法
	 */
	@Override
	public void load() {
		
		dataTable = new HashMap<String,ArrayList<Product>>();
		userTable = new HashMap<String,User>();

		ArrayList<Product> productArrayList = null;
		StringTokenizer st = null;

		Product productObject = null;
		User userObject = null;
		String line = "";

		String productName, cas, structure, formula, price, realstock, category;
		String userName, password,phoneNum, authority;

		try {
			log("读取文件: " + PRODUCT_FILE_NAME + "...");
			BufferedReader inputFromFile1 = new BufferedReader(new FileReader(PRODUCT_FILE_NAME));

			while ((line = inputFromFile1.readLine()) != null) {

				st = new StringTokenizer(line, ",");

				productName = st.nextToken().trim();
				cas = st.nextToken().trim();
				structure = st.nextToken().trim();
				formula = st.nextToken().trim();
				price = st.nextToken().trim();
				realstock = st.nextToken().trim();
				category = st.nextToken().trim();

				productObject = getProductObject(productName, cas, structure,formula, price, realstock, category);

				if (dataTable.containsKey(category)) {
					productArrayList = dataTable.get(category);
				} else {
					productArrayList = new ArrayList<Product>();
					dataTable.put(category, productArrayList);
				}
				productArrayList.add(productObject);
			}

			inputFromFile1.close();
			log("文件读取结束!");

			line = "";
			log("读取文件: " + USER_FILE_NAME + "...");
			BufferedReader inputFromFile2 = new BufferedReader(new FileReader(USER_FILE_NAME));
			while ((line = inputFromFile2.readLine()) != null) {

				st = new StringTokenizer(line, ",");

				userName = st.nextToken().trim();
				password = st.nextToken().trim();
				authority = st.nextToken().trim();
				userObject = new User(userName, password,Integer.parseInt(authority));

				if (!userTable.containsKey(userName)) {
					userTable.put(userName, userObject);
				}
			}

			inputFromFile2.close();
			log("文件读取结束!");
			log("准备就绪!\n");
		} catch (FileNotFoundException exc) {
			log("没有找到文件: " + PRODUCT_FILE_NAME + " 或 "+USER_FILE_NAME+".");
			log(exc);
		} catch (IOException exc) {
			log("读取文件发生异常: " + PRODUCT_FILE_NAME+ " 或 "+USER_FILE_NAME+".");
			log(exc);
		}
	}

	/**
	 * 返回带有这些参数的商品对象
	 * @param productName 药品名称
	 * @param cas 化学文摘登记号
	 * @param structure 结构图名称
	 * @param formula 公式
	 * @param price 价格
	 * @param realstock 数量
	 * @param category 类别
	 * @return new Product(productName, cas, structure, formula, price, realstock, category);
	 */
	private Product getProductObject(String productName, String cas,
			String structure, String formula, String price, String realstock, String category) {
		return new Product(productName, cas, structure, formula, price, realstock, category);
	}

	/**
	 * 保存用户数据
	 */

	public boolean saveUser(User user) {
		log("读取文件: " + USER_FILE_NAME + "...");
		try {
			String userinfo = user.getUsername() + "," + user.getPassword() + "," + user.getAuthority();
			RandomAccessFile fos = new RandomAccessFile(USER_FILE_NAME, "rws");
			fos.seek(fos.length());
			fos.write(("\n" + userinfo).getBytes());
			fos.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	/**
	 * 保存产品数据
	 */

	public boolean saveProduct(Product product) {
		log("读取文件: " + PRODUCT_FILE_NAME + "...");
		try {
			String productInfo = product.getProductname() 
					            + "," 
					            + product.getCas()
					            + ",ss.jpg," 
					            +product.getFormula()
					            +","
					            +product.getPrice()
					            +","
					            +product.getRealstock()
					            +","
					            +product.getCategory();
			RandomAccessFile fos = new RandomAccessFile(PRODUCT_FILE_NAME, "rws");
			fos.seek(fos.length());
			fos.write(("\n" + productInfo).getBytes());
			fos.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	/**
	 * 删除产品数据
	 */

	public boolean deleteProduct(Product product) {
		log("读取文件: " + PRODUCT_FILE_NAME + "...");
		Path filePath = Paths.get(PRODUCT_FILE_NAME);
	    List<String> lines = null;
	    try {
	    	
	        lines = Files.readAllLines(filePath);
	    } catch (IOException e) {
	        e.printStackTrace();
	        return false;
	    }
        
	    // 创建一个新的列表来存储更新后的行
	    List<String> updatedLines = new ArrayList<>();
	    boolean updated = false;

	    for (String line : lines) {
	        String[] fields = line.split(","); // 假设每行都是由逗号分隔的字段
	        if (fields.length > 6 && fields[0].equals(product.getProductname())) {
	            // 找到产品名匹配的行，就删除这一行，不用做任何操作
	            updated = true;
	        }else {
	        	// 将更新后的行（或原样的行）添加到新列表中
		        updatedLines.add(String.join(",", fields));
	        }
	      
	    }

	    // 如果没有找到匹配的产品名，则不执行任何操作
	    if (!updated) {
	        log("产品未找到！");
	        return false;
	    }

	    // 将更新后的行写回文件
	    try (BufferedWriter writer = Files.newBufferedWriter(filePath)) {
	    	Iterator<String> lineIterator = updatedLines.iterator();
	        while (lineIterator.hasNext()) {
	            String line = lineIterator.next();

	            writer.write(line);

	            // 检查是否还有更多的行需要写入
	            if (lineIterator.hasNext()) {
	                writer.newLine(); // 只有在还有更多行时才添加换行符
	            }
	        }

	    } catch (IOException e) {
	        e.printStackTrace();
	        return false;
	    }

	    log("产品删除完成。");
	    return true;
       
	}
	
	/**
	 * 更新密码
	 */
	public boolean updatePassword(User user) {  
		 log("读取文件: " + USER_FILE_NAME + "...");

		    Path filePath = Paths.get(USER_FILE_NAME);
		    List<String> lines = null;
		    try {
		        lines = Files.readAllLines(filePath);
		    } catch (IOException e) {
		        e.printStackTrace();
		        return false;
		    }

		    // 创建一个新的列表来存储更新后的行
		    List<String> updatedLines = new ArrayList<>();
		    boolean updated = false;

		    for (String line : lines) {
		        String[] fields = line.split(","); // 假设每行都是由逗号分隔的字段
		        if (fields.length >= 2 && fields[0].equals(user.getUsername())) {
		            // 找到用户名匹配的行，更新密码并标记为已更新
		            fields[1] = user.getPassword(); // 假设密码是第二个字段
		            updated = true;
		        }
		        // 将更新后的行（或原样的行）添加到新列表中
		        updatedLines.add(String.join(",", fields));
		    }

		    // 如果没有找到匹配的用户名，则不执行任何操作
		    if (!updated) {
		        log("用户未找到，密码未更新。");
		        return false;
		    }

		    // 将更新后的行写回文件
		    try (BufferedWriter writer = Files.newBufferedWriter(filePath)) {
		        for (String line : updatedLines) {
		            writer.write(line);
		            writer.newLine(); // 添加换行符
		        }
		    } catch (IOException e) {
		        e.printStackTrace();
		        return false;
		    }

		    log("用户密码更新完成。");
		    return true;
    }  
	
	
	
	/**
	 * 更新用户名
	 */
	public boolean updateUsername(User user,String newUsername) {  
		    log("读取文件: " + USER_FILE_NAME + "...");

		    Path filePath = Paths.get(USER_FILE_NAME);
		    List<String> lines = null;
		    try {
		        lines = Files.readAllLines(filePath);
		    } catch (IOException e) {
		        e.printStackTrace();
		        return false;
		    }

		    // 创建一个新的列表来存储更新后的行
		    List<String> updatedLines = new ArrayList<>();
		    boolean updated = false;

		    for (String line : lines) {
		        String[] fields = line.split(","); // 假设每行都是由逗号分隔的字段
		        if (fields.length >= 2 && fields[0].equals(user.getUsername())) {
		            // 找到用户名匹配的行，更新密码并标记为已更新
		            fields[0] = newUsername; // 假设密码是第二个字段
		            updated = true;
		        }
		        // 将更新后的行（或原样的行）添加到新列表中
		        updatedLines.add(String.join(",", fields));
		    }

		    // 如果没有找到匹配的用户名，则不执行任何操作
		    if (!updated) {
		        log("用户未找到，密码未更新。");
		        return false;
		    }

		    // 将更新后的行写回文件
		    try (BufferedWriter writer = Files.newBufferedWriter(filePath)) {
		        for (String line : updatedLines) {
		            writer.write(line);
		            writer.newLine(); // 添加换行符
		        }
		    } catch (IOException e) {
		        e.printStackTrace();
		        return false;
		    }

		    log("用户名更新完成。");
		    return true;
    }  
  

	/**
	 * 日志方法.
	 */
	@Override
	protected void log(Object msg) {
		System.out.println("ProductDataAccessor类: " + msg);
	}

	@Override
	public HashMap<String,User> getUsers() {
		this.load();
		return this.userTable;
	}
	
	@Override
	public HashMap<String,ArrayList<Product>> getProducts() {
		this.load();
		return this.dataTable;
	}

	@Override
	public void save(User user) {
		// TODO Auto-generated method stub
		
	}
}
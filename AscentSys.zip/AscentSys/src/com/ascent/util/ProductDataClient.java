package com.ascent.util;

import java.io.*;
import java.net.*;
import java.util.*;
import com.ascent.bean.Product;
import com.ascent.bean.User;

/**
 * 这个类连接数据服务器来获得数据
 * @author ascent
 * @version 1.0
 */
public class ProductDataClient implements ProtocolPort {

	/**
	 * socket引用
	 */
	protected Socket hostSocket;

	/**
	 * 输出流的引用
	 */
	protected ObjectOutputStream outputToServer;

	/**
	 * 输入流的引用
	 */
	protected ObjectInputStream inputFromServer;

	/**
	 * 默认构造方法
	 */
	public ProductDataClient() throws IOException {
		this(ProtocolPort.DEFAULT_HOST, ProtocolPort.DEFAULT_PORT);
	}

	/**
	 * 接受主机名和端口号的构造方法
	 */
	public ProductDataClient(String hostName, int port) throws IOException {

		log("连接数据服务器..." + hostName + ":" + port);

		hostSocket = new Socket(hostName, port);
		outputToServer = new ObjectOutputStream(hostSocket.getOutputStream());
		inputFromServer = new ObjectInputStream(hostSocket.getInputStream());

		log("连接成功.");
	}

	/**
	 * 返回类别集合
	 */
	@SuppressWarnings("unchecked")
	public ArrayList<String> getCategories() throws IOException {

		ArrayList<String> categoryList = null;

		try {
			log("发送请求: OP_GET_PRODUCT_CATEGORIES");
			outputToServer.writeInt(ProtocolPort.OP_GET_PRODUCT_CATEGORIES);
			outputToServer.flush();

			log("接收数据...");
			categoryList = (ArrayList<String>) inputFromServer.readObject();
			log("收到 " + categoryList.size() + " 类别.");
		} catch (ClassNotFoundException exc) {
			log("=====>>>  异常: " + exc);
			throw new IOException("找不到相关类");
		}

		return categoryList;
	}

	/**
	 * 返回产品集合
	 */
	@SuppressWarnings("unchecked")
	public ArrayList<Product> getProducts(String category) throws IOException {

		ArrayList<Product> productList = null;

		try {
			log("发送请求: OP_GET_PRODUCTS  类别 = " + category);
			outputToServer.writeInt(ProtocolPort.OP_GET_PRODUCTS);
			outputToServer.writeObject(category);
			outputToServer.flush();

			log("接收数据...");
			productList = (ArrayList<Product>)inputFromServer.readObject();
			log("收到 " + productList.size() + " 产品.");
		} catch (ClassNotFoundException exc) {
			log("=====>>>  异常: " + exc);
			throw new IOException("找不到相关类");
		}

		return productList;
	}

	/**
	 * 日志方法.
	 */
	protected void log(Object msg) {
		System.out.println("ProductDataClient类: " + msg);
	}
	
	
	/**
	 * 返回所有产品.
	 */
	@SuppressWarnings("unchecked")
	public HashMap<String,ArrayList<Product>> getAllProducts() {
		HashMap<String,ArrayList<Product>> productTable = null;

		try {
			log("发送请求: OP_GET_USERS  ");

			outputToServer.writeInt(ProtocolPort.OP_GET_ALL_PRODUCTS);
			outputToServer.flush();

			log("接收数据...");
			productTable = (HashMap<String,ArrayList<Product>>) inputFromServer.readObject();

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return productTable;
	}
	
	
	/**
	 * 增加产品
	 * @param product 产品
	 * @return boolean true:注册成功，false:注册失败
	 */
	public boolean addProduct(Product product) {
		int i=0;
		HashMap<String,ArrayList<Product>> map = this.getAllProducts();
		for (ArrayList<Product> products : map.values()) {
	            for (Product p : products) {
	                String productName = p.getProductname();
	                if (product.getProductname().equals(productName)) {
	                    i=1;
	                } 
	            }
	    }
		if (i==1) {
			return false;
		} else {
			try {
				log("发送请求: OP_ADD_USERS  ");
				outputToServer.writeInt(ProtocolPort.OP_ADD_PRODUCTS);
				outputToServer.writeObject(product);
				outputToServer.flush();
				log("接收数据...");
				try {  
				    // 读取服务器返回的响应  
				    boolean result = inputFromServer.readBoolean(); // 假设服务器返回的是一个布尔值  
				    if (result) {  
				        return true;
				    } else {  
				        return false;
				    }  
				} catch (IOException e) {  
				    log("接收数据时发生异常: " + e.getMessage());  
				    e.printStackTrace();  
				    return false;
				}
			} catch (IOException e) {
				e.printStackTrace();
				return false;
			}
		}
	}
	
	/**
	 * 删除产品
	 * @param product 产品
	 * @return boolean true:删除成功，false:删除失败
	 */
	public boolean deleteProduct(Product product) {
		int i=0;
		HashMap<String,ArrayList<Product>> map = this.getAllProducts();
		for (ArrayList<Product> products : map.values()) {
	            for (Product p : products) {
	                String productName = p.getProductname();
	                if (product.getProductname().equals(productName)) {
	                    i=1;
	                } 
	            }
	    }
		if (i==1) {
			try {
				log("发送请求: OP_DELETE_PRODUCTS  ");
				outputToServer.writeInt(ProtocolPort.OP_DELETE_PRODUCTS);
				outputToServer.writeObject(product);
				outputToServer.flush();
				log("接收数据...");
				try {  
				    // 读取服务器返回的响应  
				    boolean result = inputFromServer.readBoolean(); // 假设服务器返回的是一个布尔值  
				    if (result) {  
				        return true;
				    } else {  
				        return false;
				    }  
				} catch (IOException e) {  
				    log("接收数据时发生异常: " + e.getMessage());  
				    e.printStackTrace();  
				    return false;
				}
			} catch (IOException e) {
				e.printStackTrace();
				return false;
			}
		} 
		else {
			return false;
		}
	}
}
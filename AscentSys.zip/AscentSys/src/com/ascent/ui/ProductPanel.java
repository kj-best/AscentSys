package com.ascent.ui;

import javax.swing.*;
import javax.swing.event.*;

import com.ascent.bean.Product;
import com.ascent.util.ProductDataClient;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

import java.io.*;

/**
 * 这个类构建产品面板
 * @author ascent
 * @version 1.0
 */
@SuppressWarnings("serial")
public class ProductPanel extends JPanel {

	protected JLabel selectionLabel;

	protected JComboBox categoryComboBox;

	protected JPanel topPanel;

	protected JList productListBox;

	protected JScrollPane productScrollPane;

	protected JButton detailsButton;

	protected JButton addButton;
	
	protected JButton deleteButton;
	
	protected JButton clearButton;


	protected JButton shoppingButton;

	protected JPanel bottomPanel;

	protected MainFrame parentFrame;

	protected ArrayList<Product> productArrayList;

	protected ProductDataClient myDataClient;

	/**
	 * 构建产品面板的构造方法
	 * @param theParentFrame 面板的父窗体
	 */
	public ProductPanel(MainFrame theParentFrame) {
		try {
			
			parentFrame = theParentFrame;
			myDataClient = new ProductDataClient();
			selectionLabel = new JLabel("选择类别");
			categoryComboBox = new JComboBox();
			categoryComboBox.addItem("所有药品");

			ArrayList categoryArrayList = myDataClient.getCategories();

			Iterator iterator = categoryArrayList.iterator();
			String aCategory;

			while (iterator.hasNext()) {
				aCategory = (String) iterator.next();
				categoryComboBox.addItem(aCategory);
			}

			topPanel = new JPanel();
			productListBox = new JList();
			productListBox.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			productScrollPane = new JScrollPane(productListBox);

			detailsButton = new JButton("详细信息");
			
			
			clearButton = new JButton("清空");
			
			addButton=new JButton("添加产品");
			
			deleteButton=new JButton("删除产品");
		
			shoppingButton = new JButton("查看购物车");

			bottomPanel = new JPanel();   //底部

			this.setLayout(new BorderLayout());

			topPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
			topPanel.add(selectionLabel);
			topPanel.add(categoryComboBox);

			this.add(BorderLayout.NORTH, topPanel);
			this.add(BorderLayout.CENTER, productScrollPane);

			bottomPanel.setLayout(new FlowLayout());
			bottomPanel.add(shoppingButton);
			bottomPanel.add(detailsButton);
			bottomPanel.add(addButton);
			bottomPanel.add(deleteButton);
			bottomPanel.add(clearButton);
		

			this.add(BorderLayout.SOUTH, bottomPanel);

			detailsButton.addActionListener(new DetailsActionListener());
			clearButton.addActionListener(new ClearActionListener());
		
			
			shoppingButton.addActionListener(new ShoppingActionListener());
			categoryComboBox.addItemListener(new GoItemListener());
			productListBox.addListSelectionListener(new ProductListSelectionListener());
			addButton.addActionListener(new addProductActionListener());
			deleteButton.addActionListener(new deleteProductActionListener());

			detailsButton.setEnabled(false);
			clearButton.setEnabled(false);
			shoppingButton.setEnabled(false);
			deleteButton.setEnabled(false);
			
			
			HashMap<String,ArrayList<Product>> map=myDataClient.getAllProducts();
			populateListBox(map);
			

		} catch (IOException exc) {
			JOptionPane.showMessageDialog(this, "网络问题 " + exc, "网络问题", JOptionPane.ERROR_MESSAGE);
			System.exit(1);
		}
		
		
	}
	

	/**
	 * 设置下拉列选中的分类选项
	 */
	protected void populateListBox(HashMap<String,ArrayList<Product>> map) {
		
		String category = (String) categoryComboBox.getSelectedItem();
		if (!category.startsWith("所有")) {
			productArrayList = map.getOrDefault(category, new ArrayList<>()); // 使用getOrDefault避免NullPointerException
		} else {
			productArrayList=new ArrayList<Product>();
			Collection<ArrayList<Product>> collectionOfLists = map.values(); // 假设这是你的集合
			for (ArrayList<Product> list : collectionOfLists) {
				productArrayList.addAll(list);
			}
		}

		Object[] theData = productArrayList.toArray();
	    

		System.out.println(productArrayList + ">>>>>>>>>>>");
		 
		productListBox.setListData(theData);
		productListBox.updateUI();
		

		if (productArrayList.size() > 0) {
			clearButton.setEnabled(true);
		} else {
			clearButton.setEnabled(false);
		}
		
	}

	/**
	 * 处理选择详细...按钮时触发的事件监听器
	 * @author ascent
	 */
	class DetailsActionListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			int index = productListBox.getSelectedIndex();
			Product product = (Product) productArrayList.get(index);
			ProductDetailsDialog myDetailsDialog = new ProductDetailsDialog(parentFrame, product, shoppingButton);
			myDetailsDialog.setVisible(true);
		}
	}
	
	/**
	 * 处理删除产品按钮时触发的事件监听器
	 * @author ascent
	 */
	class deleteProductActionListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			int index = productListBox.getSelectedIndex();
			Product product = (Product) productArrayList.get(index);
			
			boolean bo = myDataClient.deleteProduct(product);
			
			if (!bo) {
				JOptionPane.showMessageDialog(parentFrame, "删除失败！");  
			} else {
				HashMap<String,ArrayList<Product>> map=myDataClient.getAllProducts();
				populateListBox(map);
			}
		}
	}

	/**
	 * 处理选择查看购物车按钮时触发的事件监听器
	 * @author ascent
	 */
	class ShoppingActionListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			ShoppingCartDialog myShoppingDialog = new ShoppingCartDialog(
					parentFrame, shoppingButton);
			myShoppingDialog.setVisible(true);
		}
	}

	

	/**
	 * 处理选择清空按钮时触发的事件监听器
	 * @author ascent
	 */
	class ClearActionListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			Object[] noData = new Object[1];
			productListBox.setListData(noData);
			categoryComboBox.setSelectedIndex(0);
		}
	}

	/**
	 * 处理选中分类下拉列选的选项时触发的事件监听器
	 * @author ascent
	 */
	class GoItemListener implements ItemListener {
		public void itemStateChanged(ItemEvent event) {
			if (event.getStateChange() == ItemEvent.SELECTED) {
				HashMap<String,ArrayList<Product>> map=myDataClient.getAllProducts();
				populateListBox(map);
				addButton.setEnabled(true);
			}
		}
	}

	/**
	 * 处理选中分类列表中选项时触发的事件监听器,选中就允许查看详细信息
	 * @author ascent
	 */
	class ProductListSelectionListener implements ListSelectionListener {
		public void valueChanged(ListSelectionEvent event) {
			if (productListBox.isSelectionEmpty()) {
				detailsButton.setEnabled(false);				
				deleteButton.setEnabled(false);
				
			} else {
				detailsButton.setEnabled(true);			
				deleteButton.setEnabled(true);
				
			}
		    
		}
	}
	
	/**
	 * 处理添加产品的功能
	 * @author ascent
	 */
	class addProductActionListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			AddProducts addproducts=new AddProducts(parentFrame);
			addproducts.setVisible(true);
		}
	}
	
	
	
	
	

}
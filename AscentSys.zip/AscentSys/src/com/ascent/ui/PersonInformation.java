package com.ascent.ui;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import com.ascent.ui.Rewrite_password.CancelActionListener;
import com.ascent.ui.Rewrite_password.MyFocusListener;
import com.ascent.ui.Rewrite_password.SaveActionListener;
import com.ascent.ui.Rewrite_password.SendYZMActionListener;
import com.ascent.util.UserDataClient;
import com.ascent.bean.*;

public class PersonInformation extends JFrame {
	protected JTextField userText;

	protected JPasswordField password;
	
	protected JPasswordField Confirm_pwd;
	
	protected JTextField phoneNumber;
	
	protected JTextField yzm;
	
	protected JLabel myName;

	protected JLabel tip;

	protected UserDataClient userDataClient;
	
	protected JCheckBox rememberMeCheckbox;
	
	protected JPanel resetPanel;
	
	protected User myPerson;

	/**
	 * 默认构造方法，初始化用户注册窗体
	 */
	public PersonInformation(User user) {
		myPerson=user;
		setTitle("个人资料");
		
// 		// 设置窗体无边框和标题栏
// 		setUndecorated(true);

 		// 设置布局和内容
 		getContentPane().setLayout(null);
 		resetPanel = new JPanel();
 		resetPanel.setLayout(null);
 		resetPanel.setOpaque(false); // 设置面板为不透明，以便背景图片可见
      
 		// ... 添加loginPanel中的组件 ...
 		
 		//标题
 		JLabel titleLabel = new JLabel("我的个人信息");
 		titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 30)); // 字体名称, 样式, 大小 
 		titleLabel.setBounds(180,50,350,30); 
 		
 		//用户名
 		JLabel userLabel = new JLabel("我的名称：");
 		userLabel.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
 		userLabel.setBounds(200,124,80,20); 
 		
 		myName = new JLabel(myPerson.getUsername());
 		myName.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
 		myName.setForeground(Color.blue);
 		myName.setBounds(275,124,200,20); 
 		
		
        //新密码
 		JLabel passwordLabel = new JLabel("我的密码：");
 		passwordLabel.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
 		passwordLabel.setBounds(200,174,80,20); 
 		
 		String a="";
 		for(int i=0;i<myPerson.getPassword().length();i++) {
 			a+="*";
 		}
 		JLabel password = new JLabel(a);
 		password.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
 		password.setForeground(Color.blue);
 		password.setBounds(275,174,200,20); 
	
		
		//确认密码
		JLabel identity = new JLabel("我的身份：");
		identity.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
		identity.setBounds(200,224,80,20); 
		
		String iden="";
		if(user.getAuthority()==0) {
			iden="普通用户";
		}else if(user.getAuthority()==1){
			iden="管理员";
		}
		JLabel myIdentity = new JLabel(iden);
		myIdentity.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
		myIdentity.setForeground(Color.blue);
		myIdentity.setBounds(275,224,200,20); 
	
		
		//手机号
 		JLabel phoneLabel = new JLabel("联系电话：");
 		phoneLabel.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
 		phoneLabel.setBounds(200,274,80,20); 
 	
		JLabel phoneNum = new JLabel("17728424362");
		phoneNum.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
		phoneNum.setForeground(Color.blue);
		phoneNum.setBounds(275,274,200,20); 
		
        //修改个人信息按钮
		JButton modifyButton = new JButton("修改个人信息");
		modifyButton.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
		modifyButton.setBackground(new Color(72, 200, 255)); // 浅蓝色的一种可能的RGB值
		modifyButton.setForeground(Color.white);
		modifyButton.setBounds(210,330,130,35);
		modifyButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // 设置鼠标悬停时光标变为手形
		
 
		resetPanel.add(phoneNum);
		resetPanel.add(passwordLabel);
		resetPanel.add(titleLabel);
		resetPanel.add(userLabel);
		resetPanel.add(myName);
		resetPanel.add(password);
		resetPanel.add(identity);
		resetPanel.add(myIdentity);
		resetPanel.add(modifyButton);
		resetPanel.add(phoneLabel);
		resetPanel.add(phoneNum);
		
		
		
		// 将loginPanel添加到内容面板，并设置其位置和大小  
		resetPanel.setBounds(0, 0, 550, 450); // 根据你的需求设置loginPanel的位置和大小  
		
        
        getContentPane().add(resetPanel);  
        getContentPane().setBackground(Color.white);
        
        modifyButton.addActionListener(new ModifyActionListener());
       
		
		setSize(550, 450);    //窗体大小
        setLocationRelativeTo(null); // 居中显示窗口
        
        

		try {
			userDataClient = new UserDataClient();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 处理"修改个人信息"按钮事件监听的内部类.
	 */
	class ModifyActionListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			// 打开另一个窗口进行修改
			ModifyPersonInfo modifyFrame = new ModifyPersonInfo(myPerson);
			modifyFrame.setVisible(true);
		}
	}
}

package com.ascent.ui;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.Arrays;
import java.util.Random;
import java.util.prefs.Preferences;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import com.ascent.ui.RegistFrame.ExitActionListener;
import com.ascent.ui.RegistFrame.MyFocusListener;
import com.ascent.ui.RegistFrame.RegistActionListener;
import com.ascent.ui.RegistFrame.SendYZMActionListener;
import com.ascent.util.UserDataClient;

import com.ascent.bean.*;

public class ModifyPersonInfo extends JFrame {
	private JTextField userText;

	private JPasswordField password;

	private JPasswordField repassword;
	
    protected JTextField phoneNumber;
	
	protected JTextField yzm;
	
	protected String yzmCode="";

	private JLabel tip;

	private UserDataClient userDataClient;
	
	private JPanel registPanel;
	
	private User myUser;
	
	public String lastname="";
	
	/**
	 * 默认构造方法，初始化用户注册窗体
	 */
	public ModifyPersonInfo(User user) {
		
		myUser=user;
		lastname=user.getUsername();
		setTitle("修改个人信息");

 		// 设置布局和内容
 		getContentPane().setLayout(null);
 		registPanel = new JPanel();
 		registPanel.setLayout(null);
 		
 		// ... 添加registPanel中的组件 ...
 		
 		//标题
 		JLabel titleLabel = new JLabel("修改我的资料");
 		titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 30)); // 字体名称, 样式, 大小 
 		titleLabel.setBounds(190,60,350,30); 
 		
 		//用户名
 		JLabel userLabel = new JLabel("用户名：");
 		userLabel.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
 		userLabel.setBounds(135,164,80,20); 
 		userText = new JTextField(15);
 		userText.setText(myUser.getUsername());
		userText.setFont(new Font("微软雅黑", Font.PLAIN, 15)); // 字体名称, 样式, 大小 
		userText.setBorder(BorderFactory.createEmptyBorder(0,5,0,0));
		JScrollPane JSuserText=new JScrollPane(userText);
        // 永远不显示水平滚动条
		JSuserText.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		JSuserText.setBounds(200,160,200,30); 
		
        //密码
 		JLabel passwordLabel = new JLabel("新密码：");
 		passwordLabel.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
 		passwordLabel.setBounds(135,214,80,20); 
		password = new JPasswordField(15);
		password.setBorder(BorderFactory.createEmptyBorder(0,5,0,0));
		password.setFont(new Font("微软雅黑", Font.PLAIN, 15)); // 字体名称, 样式, 大小 
		JScrollPane JSpassword=new JScrollPane(password);
		// 永远不显示水平滚动条
		JSpassword.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		JSpassword.setBounds(200,210,200,30); 
		
		//重复密码
		JLabel repasswordLabel = new JLabel("确认密码：");
		repasswordLabel.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
		repasswordLabel.setBounds(120,264,80,20); 
		repassword = new JPasswordField(15);
		repassword.setBorder(BorderFactory.createEmptyBorder(0,5,0,0));
		repassword.setFont(new Font("微软雅黑", Font.PLAIN, 15)); // 字体名称, 样式, 大小 
		JScrollPane JSRepassword=new JScrollPane(repassword);
		// 永远不显示水平滚动条
		JSRepassword.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		JSRepassword.setBounds(200,260,200,30); 
		
		//手机号
 		JLabel phoneLabel = new JLabel("手机号：");
 		phoneLabel.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
 		phoneLabel.setBounds(135,314,80,20); 
 		phoneNumber = new JTextField(15);
 		phoneNumber.setFont(new Font("微软雅黑", Font.PLAIN, 15)); // 字体名称, 样式, 大小 
 		phoneNumber.setBorder(BorderFactory.createEmptyBorder(0,5,0,0));
		JScrollPane JSphoneNumber=new JScrollPane(phoneNumber);
        // 永远不显示水平滚动条
		JSphoneNumber.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		JSphoneNumber.setBounds(200,310,200,30); 
		
		//验证码
 		JLabel yzmLabel = new JLabel("验证码：");
 		yzmLabel.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
 		yzmLabel.setBounds(135,364,80,20); 
 		yzm = new JTextField(15);
 		yzm.setFont(new Font("微软雅黑", Font.PLAIN, 15)); // 字体名称, 样式, 大小 
 		yzm.setBorder(BorderFactory.createEmptyBorder(0,5,0,0));
		JScrollPane JSyzm=new JScrollPane(yzm);
        // 永远不显示水平滚动条
		JSyzm.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		JSyzm.setBounds(200,360,120,30); 
		
		//发送验证码
		JButton sendYZMButton = new JButton("获取验证码");	
		sendYZMButton.setBorder(BorderFactory.createEmptyBorder());
		sendYZMButton.setBackground(new Color(72, 200, 255)); // 浅蓝色的一种可能的RGB值
		sendYZMButton.setForeground(Color.white);
		sendYZMButton.setFont(new Font("微软雅黑", Font.BOLD, 13)); // 字体名称, 样式, 大小 
		sendYZMButton.setBounds(320,359,80,30);
		sendYZMButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // 设置鼠标悬停时光标变为手形
		
		//验证码
 		JLabel tip = new JLabel("注：置空默认不修改");
 		tip.setFont(new Font("微软雅黑", Font.BOLD, 12)); // 字体名称, 样式, 大小 
 		tip.setForeground(Color.gray);
 		tip.setBounds(291,394,200,20); 
		
		JButton ModifyButton = new JButton("修改");	
		ModifyButton.setBackground(new Color(72, 200, 255)); // 浅蓝色的一种可能的RGB值
		ModifyButton.setForeground(Color.white);
		ModifyButton.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
		ModifyButton.setBounds(190,435,70,30);
		ModifyButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // 设置鼠标悬停时光标变为手形
      
		JButton cancelButton = new JButton("取消");
		cancelButton.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
		cancelButton.setBackground(new Color(72, 200, 255)); // 浅蓝色的一种可能的RGB值
		cancelButton.setForeground(Color.white);
		cancelButton.setBounds(290,435,70,30);
		cancelButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // 设置鼠标悬停时光标变为手形
		
 
		registPanel.add(tip);
		registPanel.add(repasswordLabel);
		registPanel.add(titleLabel);
		registPanel.add(userLabel);
		registPanel.add(JSuserText);
		registPanel.add(passwordLabel);
		registPanel.add(JSRepassword);
		registPanel.add(JSpassword);
		registPanel.add(ModifyButton);
		registPanel.add(cancelButton);
		registPanel.add(phoneLabel);
		registPanel.add(JSphoneNumber);
		registPanel.add(JSyzm);
		registPanel.add(yzmLabel);
		registPanel.add(sendYZMButton);
		
		
		// 将loginPanel添加到内容面板，并设置其位置和大小  
		registPanel.setBounds(0, 0, 550, 700); // 根据你的需求设置loginPanel的位置和大小  
		registPanel.setOpaque(false); // 设置面板为不透明，以便背景图片可见
        getContentPane().add(registPanel); 
        getContentPane().setBackground(Color.white);
         
        ModifyButton.addActionListener(new ModifyActionListener());
        cancelButton.addActionListener(new ExitActionListener());
        sendYZMButton.addActionListener(new SendYZMActionListener());
       
       
		
		setSize(550, 700);    //窗体大小
        setLocationRelativeTo(null); // 居中显示窗口
        
        

		try {
			userDataClient = new UserDataClient();
		} catch (IOException e) {
			e.printStackTrace();
		}
	
		
	}
	
	

	/**
	 * 取消按钮事件监听
	 * @author ascent
	 */
	class ExitActionListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			setVisible(false);
			dispose();
		}
	}

	/**
	 * 修改按钮事件监听
	 * @author ascent
	 */
	class ModifyActionListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			// 用户注册操作
			String newuserName=userText.getText();
			String phoneNum=phoneNumber.getText();
			String YZM=yzm.getText();
			char[] passWord=password.getPassword();
			char[] repassWord=repassword.getPassword();
			int un=0,ps=0,pn=0;   //代表用户名、密码和手机号的修改状态，0是无修改，1是要修改，2代表修改成功,3代表修改失败
			int stop=1;   //是否中途停止，如果是后面不用输出，0代表停止，1代表进行
			
			//和前一个用户名不相同就要修改用户名
			if(newuserName.length()!=0) {
				    if(newuserName.equals(myUser.getUsername())) {
				    	un=0;
				    }else {
				    	un=1;
				    }
					
			}
			if(passWord.length!=0) {      //如果修改了密码，那么确认密码必须填写
				if(repassWord.length==0) {
					JOptionPane.showMessageDialog(registPanel, "确认密码不能为空！");  
					stop=0;
				}else {
					if(!Arrays.equals(passWord, repassWord)) {
						JOptionPane.showMessageDialog(registPanel, "修改失败！两次密码不一致！");  
						stop=0;
					}else {
						ps=1;
					}
				}
			}
		    if(phoneNum.length()!=0){
		    	if(phoneNum.length()!=11) {
		    		JOptionPane.showMessageDialog(registPanel, "请输入11位数字的手机号！"); 
		    		stop=0;
		    	}else {
		    		if(YZM.length()!=6){
						JOptionPane.showMessageDialog(registPanel, "修改手机号必须输入6位数字的验证码！");  
						stop=0;
					}else if(!yzmCode.equals(YZM)) {
							JOptionPane.showMessageDialog(registPanel, "错误的验证码！请重新输入！");  
							stop=0;
					}else {
						pn=1;
					}
		    	}
			}
		    
		    String modifyText="";
		    
		    if(un==1){
				//用户名需要修改，执行修改用户名操作  
	            boolean success = userDataClient.resetUserName(lastname,newuserName);  
	            if (success) {  	
	                un=2;   //修改成功
	                modifyText+="用户名：修改成功！";
	                lastname=newuserName;
	            } else {  	          
	                un=3;   //修改失败
	                modifyText+="用户名：修改失败！";
	            }  
			}

			if(ps==1){
				//密码一致，执行重置密码操作  
	            boolean success = userDataClient.resetPassword(newuserName, new String(passWord));  
	            if (success) {  		          
	                ps=2;   //修改成功	                
	                modifyText+="\n密码：修改成功！";
	               
	            } else {  	          
	                ps=3;   //修改失败               
	                modifyText+="\n密码：修改失败！";	                
	            }  
			}
		
			
			
//			if(pn==1){
//				//密码一致，执行重置密码操作  
//	            boolean success = userDataClient.resetPhoneNum(userName, new String(phoneNum));  
//	            if (success) {  		          
//	                ps=2;   //修改成功
//	            } else {  	          
//	                ps=3;   //修改失败
//	            }  
//			}
			
			if(stop==1) {
				if(modifyText.length()==0) {
					JOptionPane.showMessageDialog(registPanel, "无修改！");  
				}else {
					JOptionPane.showMessageDialog(registPanel, modifyText);  
				}
			}
			
		}
	}

	/**
	 * "关闭窗口"事件处理内部类
	 * @author ascent
	 */
	class WindowCloser extends WindowAdapter {
		public void windowClosing(WindowEvent e) {
			setVisible(false);
			dispose();
		}
	}
	
	/**
	 * 发送验证码按钮事件监听
	 * @author ascent
	 */
	class SendYZMActionListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0) {
			String phoneNum =phoneNumber.getText();
			int len=phoneNum.length();
			if(len!=11) {
				JOptionPane.showMessageDialog(registPanel,"请输入11位的手机号码！");  
			}else {
				// 生成六位数字的验证码
	            yzmCode = String.valueOf(generateRandomCode(6));
	            // 打印验证码，实际中这里应该是发送验证码的逻辑
	         
	            JOptionPane.showMessageDialog(registPanel,"验证码："+yzmCode);  
	            // 这里可以添加发送验证码到手机的逻辑，例如调用短信服务API
//	            sendSMSToPhone(phoneNum, String.valueOf(code));
			}
			 
		}
	}
	
	// 生成指定长度的随机数字
    private int generateRandomCode(int length) {
        Random random = new Random();
        int code = 0;
        for (int i = 0; i < length; i++) {
            code = code * 10 + random.nextInt(10); // 生成0-9之间的随机数
        }
        return code;
    }
}

package com.ascent.ui;

import javax.swing.*;
import javax.swing.event.*;

import com.ascent.bean.Product;
import com.ascent.util.ProductDataClient;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

import java.io.*;

/**
 * 这个类构建产品面板
 * @author ascent
 * @version 1.0
 */
@SuppressWarnings("serial")
public class ProductPanel3 extends JPanel {

	protected JLabel productNameLabel;

	protected JList productListBox;

	protected JPanel topPanel;

	
	protected JTextField productName;
	
	protected JTextField productCategory;

	protected JScrollPane productScrollPane;

	protected JButton detailsButton;

	protected JButton addButton;
	
	protected JButton deleteButton;
	
	protected JButton clearButton;

	protected JButton findButton;

	protected JButton shoppingButton;

	protected JPanel bottomPanel;

	protected MainFrame parentFrame;

	protected ArrayList<Product> productArrayList;

	protected ProductDataClient myDataClient;

	/**
	 * 构建产品面板的构造方法
	 * @param theParentFrame 面板的父窗体
	 */
	public ProductPanel3(MainFrame theParentFrame) {
		try {
			
			parentFrame = theParentFrame;
			myDataClient = new ProductDataClient();
			
			//药品名称
	 		JLabel productNameLabel = new JLabel("药品名:");
	
	 		
			//药品名称输入框
			productName = new JTextField(13);
			productName.setBorder(BorderFactory.createEmptyBorder(0,5,0,0)); 
			productName.setFont(new Font("微软雅黑", Font.PLAIN, 11));
			productName.setPreferredSize(new Dimension(250, 25));
			JScrollPane JSproductName=new JScrollPane(productName);
			
			//去掉滚动面板的边框
			JSproductName.setBorder(BorderFactory.createEmptyBorder());
			// 永远不显示水平滚动条
			JSproductName.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
			
			findButton = new JButton("搜索");
		
			topPanel = new JPanel();
			
			topPanel.add(productNameLabel);
			topPanel.add(JSproductName);
			topPanel.add(findButton);
			
			productListBox = new JList();
			productListBox.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			productScrollPane = new JScrollPane(productListBox);

			detailsButton = new JButton("详细信息");
			
			clearButton = new JButton("清空");
			
			addButton=new JButton("添加产品");
			
			deleteButton=new JButton("删除产品");
		
			shoppingButton = new JButton("查看购物车");

			bottomPanel = new JPanel();   //底部

			this.setLayout(new BorderLayout());

			topPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
			

			this.add(BorderLayout.NORTH, topPanel);
			this.add(BorderLayout.CENTER, productScrollPane);

			bottomPanel.setLayout(new FlowLayout());
			bottomPanel.add(shoppingButton);
			bottomPanel.add(detailsButton);
			bottomPanel.add(addButton);
			bottomPanel.add(deleteButton);
			bottomPanel.add(clearButton);
		

			this.add(BorderLayout.SOUTH, bottomPanel);

            
			clearButton.addActionListener(new ClearActionListener());
		
			
			shoppingButton.addActionListener(new ShoppingActionListener());
			
			addButton.addActionListener(new addProductActionListener());
			deleteButton.addActionListener(new deleteProductActionListener());
			findButton.addActionListener(new FindProductActionListener());

			detailsButton.setEnabled(false);
			clearButton.setEnabled(false);
			shoppingButton.setEnabled(false);
			deleteButton.setEnabled(false);
			addButton.setEnabled(false);

		} catch (IOException exc) {
			JOptionPane.showMessageDialog(this, "网络问题 " + exc, "网络问题", JOptionPane.ERROR_MESSAGE);
			System.exit(1);
		}
	}
	
	protected void findProduct(String pName) {
		productArrayList=new ArrayList<Product>();
		HashMap<String,ArrayList<Product>> map =myDataClient.getAllProducts();
		for (ArrayList<Product> products : map.values()) {
	            for (Product p : products) {
	                String productName = p.getProductname();
	                if (productName.contains(pName)) {
	                	productArrayList.add(p);
	                } 
	            }
	    }

		Object[] theData = productArrayList.toArray();
	    

		System.out.println(productArrayList + ">>>>>>>>>>>");
		 
		productListBox.setListData(theData);
		productListBox.updateUI();
		

		if (productArrayList.size() > 0) {
			clearButton.setEnabled(true);
		} else {
			clearButton.setEnabled(false);
		}
		
	}
	
	
	/**
	 * 处理查询按钮时触发的事件监听器
	 * @author ascent
	 */
	class FindProductActionListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			String pName=productName.getText();
			findProduct(pName);
		}
	}

	
	/**
	 * 处理删除产品按钮时触发的事件监听器
	 * @author ascent
	 */
	class deleteProductActionListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			int index = productListBox.getSelectedIndex();
			Product product = (Product) productArrayList.get(index);
			boolean bo = myDataClient.deleteProduct(product);
			
			if (!bo) {
				JOptionPane.showMessageDialog(parentFrame, "删除失败！");  
			} else {
				HashMap<String,ArrayList<Product>> map=myDataClient.getAllProducts();
				
			}
		}
	}

	/**
	 * 处理选择查看购物车按钮时触发的事件监听器
	 * @author ascent
	 */
	class ShoppingActionListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			ShoppingCartDialog myShoppingDialog = new ShoppingCartDialog(
					parentFrame, shoppingButton);
			myShoppingDialog.setVisible(true);
		}
	}

	

	/**
	 * 处理选择清空按钮时触发的事件监听器
	 * @author ascent
	 */
	class ClearActionListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			Object[] noData = new Object[1];
			productListBox.setListData(noData);
			
		}
	}

	
	
	/**
	 * 处理添加产品的功能
	 * @author ascent
	 */
	class addProductActionListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			AddProducts addproducts=new AddProducts(parentFrame);
			addproducts.setVisible(true);
		}
	}
	
	
	
	
	

}
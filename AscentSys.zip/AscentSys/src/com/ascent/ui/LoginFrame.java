package com.ascent.ui;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.HashMap;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import com.ascent.bean.User;
import com.ascent.util.UserDataClient;

import javax.swing.*;
import java.awt.*;
import java.net.URL;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.awt.image.BufferedImage;


import java.awt.event.MouseAdapter;  
import java.awt.event.MouseEvent; 

import java.util.prefs.Preferences;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;

import java.util.concurrent.ExecutionException;

/**
 * 用户登陆窗体
 * @author ascent
 * @version 1.0
 */
@SuppressWarnings("serial")
public class LoginFrame extends JFrame {

	protected JTextField userText;

	protected JPasswordField password;
	
	protected JTextField phoneNumber;
	
	protected JTextField yzm;

	protected JLabel tip;

	protected UserDataClient userDataClient;
	
	protected JCheckBox rememberMeCheckbox=new JCheckBox("记住密码");
	
	protected JCheckBox automaticLogin=new JCheckBox("自动登录");
	
	protected JPanel loginPanel;
	
	protected JButton loginButton;
	
	protected JLabel titleLabel;
	
	
    private static final String USERNAME_KEY = "username";
    private static final String PASSWORD_KEY = "password";
    private static final String REMEMBER_ME_KEY = "rememberMe";
    private static final String LAST_LOGIN_SUCCESS_time_KEY = "lastloginSuccessTime";
    private static final String Automatic_Login_KEY = "Automatic_Login";
	

	/**
	 * 默认的构造方法，初始化登陆窗体
	 */
	public LoginFrame() {
		Initial();
	}
	
	public LoginFrame(boolean Auto_Yes_Or_No) {
		if(!Auto_Yes_Or_No) {
			setAutomaticLoginKey(Auto_Yes_Or_No);
		}
		Initial();
	}
	
	private void Initial(){
        setTitle("系统登录");
		
 		try {
            // 加载背景图片
            URL imageUrl = getClass().getResource("/images/bg.jpg");
            BufferedImage backgroundImage = ImageIO.read(imageUrl);
            
            
           
            // 设置窗体背景
            setContentPane(new JPanel() {
                @Override
                protected void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    if (backgroundImage != null) {
                        g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                    }
                }
            });
            
         
        } catch (IOException e) {
            // 处理图片加载错误
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "无法加载背景图片", "错误", JOptionPane.ERROR_MESSAGE);
        }

 		// 设置布局和内容
 		getContentPane().setLayout(null);
 		loginPanel = new JPanel();
 		loginPanel.setLayout(null);
 		loginPanel.setOpaque(false); // 设置面板为不透明，以便背景图片可见
      
 		// ... 添加loginPanel中的组件 ...
 		
 		//标题
 		titleLabel = new JLabel("欢迎登录艾斯医药系统");
 		titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 30)); // 字体名称, 样式, 大小 
 		titleLabel.setForeground(Color.WHITE); // 设置字体颜色为白色
 		titleLabel.setBounds(275,60,350,30); 
 		
 		//用户名
 		JLabel userLabel = new JLabel("用户名：");
 		userLabel.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
 		userLabel.setForeground(Color.WHITE); // 设置字体颜色为白色
 		userLabel.setBounds(290,164,80,20); 
 		
 		//用户名输入框
 		userText = new JTextField(15);
		userText.setFont(new Font("微软雅黑", Font.PLAIN, 15)); // 字体名称, 样式, 大小 
		userText.setBorder(BorderFactory.createEmptyBorder(0,5,0,0));
		JScrollPane JSuserText=new JScrollPane(userText);
		//去掉滚动面板的边框
		JSuserText.setBorder(BorderFactory.createEmptyBorder());
        // 永远不显示水平滚动条
		JSuserText.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		JSuserText.setBounds(353,160,200,30); 
		
        //密码
 		JLabel passwordLabel = new JLabel("密码：");
 		passwordLabel.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
 		passwordLabel.setForeground(Color.WHITE); // 设置字体颜色为红色
 		passwordLabel.setBounds(305,214,80,20); 
 		
		//密码输入框
		password = new JPasswordField(15);
		password.setBorder(BorderFactory.createEmptyBorder(0,5,0,0));
		password.setFont(new Font("微软雅黑", Font.PLAIN, 15)); // 字体名称, 样式, 大小 
		JScrollPane JSpassword=new JScrollPane(password);
		//去掉滚动面板的边框
		JSpassword.setBorder(BorderFactory.createEmptyBorder());
		// 永远不显示水平滚动条
		JSpassword.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		JSpassword.setBounds(353,210,200,30); 
		
		//身份
		JLabel identity = new JLabel("身份：");
		identity.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
		identity.setForeground(Color.WHITE); // 设置字体颜色为红色
		identity.setBounds(305,264,80,20); 
		
		// 身份下拉框，创建一个新的JComboBox实例，并添加选项  
        JComboBox<String> comboBox = new JComboBox<>();  
        comboBox.setBorder(BorderFactory.createEmptyBorder(-2,-3,-2,-2));
        comboBox.setFont(new Font("微软雅黑", Font.PLAIN, 15));
        comboBox.setBackground(Color.white);
        //普通用户只能查询、购买药品
        comboBox.addItem(" 普通用户");
        //管理员可以添加、删除产品或用户
        comboBox.addItem(" 管理员"); 
        //超级管理员主要是管理所有管理员和普通用户，独有权限是升级普通用户为管理员和降级管理员为普通用户  
        comboBox.addItem(" 超级管理员");   
        comboBox.setBounds(353,260,200,30);
        
      
		loginButton = new JButton("登陆");	
		loginButton.setBackground(new Color(0, 240, 240)); // 浅蓝色的一种可能的RGB值
		loginButton.setForeground(Color.white);
		loginButton.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
		loginButton.setBounds(335,335,70,30);
		loginButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // 设置鼠标悬停时光标变为手形
      
		JButton regist = new JButton("注册");
		regist.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
		regist.setBackground(new Color(0, 240, 240)); // 浅蓝色的一种可能的RGB值
		regist.setForeground(Color.white);
		regist.setBounds(450,335,70,30);
		regist.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // 设置鼠标悬停时光标变为手形
		
      
		//自动登录
		automaticLogin.setFont(new Font("黑体", Font.BOLD, 11)); // 字体名称, 样式, 大小 
		automaticLogin.setOpaque(false); 
		automaticLogin.setForeground(Color.white);
		automaticLogin.setBounds(405,295,90,25);
		automaticLogin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // 设置鼠标悬停时光标变为手形

		//记住密码
		rememberMeCheckbox.setFont(new Font("黑体", Font.BOLD, 11)); // 字体名称, 样式, 大小 
		rememberMeCheckbox.setOpaque(false); 
		rememberMeCheckbox.setForeground(Color.white);
		rememberMeCheckbox.setBounds(485,295,90,25);
		rememberMeCheckbox.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // 设置鼠标悬停时光标变为手形
		
		//忘记密码
		JLabel forgot_password = new JLabel("忘记密码?"); 
		forgot_password.setFont(new Font("微软雅黑", Font.PLAIN, 15)); // 字体名称, 样式, 大小 
		forgot_password.setForeground(Color.red); // 设置字体颜色为红色
		forgot_password.setBounds(395,390,80,20); 
		forgot_password.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // 设置鼠标悬停时光标变为手形
		
		// 忘记密码添加鼠标监听器  
        forgot_password.addMouseListener(new MouseAdapter() {  
            @Override  
            public void mouseClicked(MouseEvent e) {  
                if (e.getClickCount() == 1) { // 检查是否是单击事件  
                    // 打开另一个窗口修改密码  
                    Rewrite_password rewrite_pwd=new Rewrite_password();
        			rewrite_pwd.setVisible(true);
                }  
            }  
            @Override  
            public void mouseEntered(MouseEvent e) {  
                // 鼠标进入标签时改变文字颜色  
                forgot_password.setForeground(Color.white);  
            }  

            @Override  
            public void mouseExited(MouseEvent e) {  
                // 鼠标离开标签时恢复文字颜色  
                forgot_password.setForeground(Color.red);  
            }  
            @Override  
            public void mousePressed(MouseEvent e) {  
                // 鼠标按住标签时改变文字颜色  
                forgot_password.setForeground(Color.blue); 
            }  
            @Override  
            public void mouseReleased(MouseEvent e) {  
                // 鼠标按住标签时恢复文字颜色  
                forgot_password.setForeground(Color.red); 
            }  
        });  
        
		loginPanel.add(forgot_password);
		loginPanel.add(rememberMeCheckbox);
		loginPanel.add(automaticLogin);
		loginPanel.add(titleLabel);
		loginPanel.add(userLabel);
		loginPanel.add(JSuserText);
		loginPanel.add(passwordLabel);
		loginPanel.add(identity);
		loginPanel.add(comboBox);
		loginPanel.add(JSpassword);
		loginPanel.add(loginButton);
		loginPanel.add(regist);
	
		// 将loginPanel添加到内容面板，并设置其位置和大小  
        loginPanel.setBounds(0, 0, 850, 550); // 根据你的需求设置loginPanel的位置和大小  
        
        
        getContentPane().add(loginPanel);  
          
		loginButton.addActionListener(new LoginActionListener());
		regist.addActionListener(new RegistActionListener());
		automaticLogin.addActionListener(new AutoLoginActionListener());
		rememberMeCheckbox.addActionListener(new RememberMEActionListener());
		
		
		setSize(850, 550);    //窗体大小
        setLocationRelativeTo(null); // 居中显示窗口
        
		try {
			userDataClient = new UserDataClient();
			loadSavedCredentials();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 处理"登陆"按钮事件监听的内部类
	 */
	class LoginActionListener implements ActionListener {
		
		public void actionPerformed(ActionEvent e) {
			Login(2);
		}
		public void Login(int i) {          //i是1代表自动登录，2代表按钮登录
			String userName=userText.getText();
			char[] chr = password.getPassword();
			String pwd = new String(chr);
			if(userName.length()==0) {
				JOptionPane.showMessageDialog(loginPanel, "请输入用户名！");  
			}else if(pwd.length()==0) {
				JOptionPane.showMessageDialog(loginPanel, "请输入密码！");  
			}else {
				boolean bo = false;
				HashMap userTable = userDataClient.getUsers();
				
				if (userTable != null) {
					if (userTable.containsKey(userName)) {
						User userObject = (User) userTable.get(userName);
						if (userObject.getPassword().equals(pwd)) {
							bo = true;
						}
					}
					if (bo) {
			            // 使用SwingWorker在后台线程执行登录操作
		                SwingWorker<Void, Void> loginWorker = new SwingWorker<Void, Void>() {
			                @Override
			                protected Void doInBackground() throws Exception {
			                    RememberPWD();
			                    automatic_login();
			                    userDataClient.closeSocKet();; // 假设这是关闭网络连接的方法
			                    ProSleep(500);
			                    if(i==1) {
			                    	 titleLabel.setText("      正在自动登录...");
					                 ProSleep(1000);
					                 titleLabel.setText("          登录成功");
					                 ProSleep(500);
			                    }
			                    return null;
		                    }
			                @Override
			                protected void done() {
			                    try {
			                        get(); // 获取执行结果，可能会抛出异常		                   
			                        // 登录成功后的操作		             
			                        setVisible(false);
			                        dispose();
			                        User userObject = (User) userTable.get(userName);
			                        MainFrame myFrame = new MainFrame(userObject);
			                        myFrame.setVisible(true);
			                    } catch (InterruptedException | ExecutionException ex) {
			                        // 登录失败或发生异常的处理
			                        ex.printStackTrace();
			                        JOptionPane.showMessageDialog(loginPanel, "登录失败: " + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
			                    } finally {
			                        // 无论成功还是失败，都隐藏进度条并启用登录按钮
			                       
			                        loginButton.setEnabled(true);
			                    }
			                }
		                };
		                loginWorker.execute(); // 执行SwingWorker
					} else {
						 JOptionPane.showMessageDialog(loginPanel, "帐号不存在,或密码错误.");  
					}
				} else {
					 JOptionPane.showMessageDialog(loginPanel, "服务器连接失败,请稍候再试.");  
				}
			}
		}
	}
	
	public void ProSleep(int millisecond) {
		   // 登录成功后的操作
        try {
            // 让当前线程睡眠五秒（3000毫秒）
            Thread.sleep(millisecond);       			                      
        } catch (InterruptedException e) {
            // 处理InterruptedException
            System.err.println("线程睡眠被中断: " + e.getMessage());
        }
	}

	/**
	 * 处理"注册"按钮事件监听的内部类.
	 */
	class RegistActionListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			// 打开注册用户的窗口
			RegistFrame registFrame = new RegistFrame();
			registFrame.setVisible(true);
		}
	}
	
	/**
	 * 处理"自动登录"复选框事件监听的内部类.
	 */
	class AutoLoginActionListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			//如果选择乐自动登录,那么记住密码也要被选上,取消就一起取消
			if(automaticLogin.isSelected()) {
				rememberMeCheckbox.setSelected(true);
			}else {
				rememberMeCheckbox.setSelected(false);
			}
		}
	}
	
	/**
	 * 处理"记住密码"复选框事件监听的内部类.
	 */
	class RememberMEActionListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			//如果选择乐自动登录,那么记住密码也要被选上,取消就一起取消
			if(!rememberMeCheckbox.isSelected()) {
				automaticLogin.setSelected(false);
			}
		}
	}
	
	/**
	 * 实现"记住密码"功能.
	 */
	public void RememberPWD() {
		if (rememberMeCheckbox.isSelected()) {
            Preferences prefs = Preferences.userNodeForPackage(getClass());
            prefs.put(USERNAME_KEY, userText.getText());
            // 注意：不要直接存储密码明文！这里仅为示例。
            // 在实际应用中，应该存储密码的哈希值或加密后的版本。
            prefs.put(PASSWORD_KEY, new String(password.getPassword()));
            prefs.putBoolean(REMEMBER_ME_KEY, true);
            // 将LocalDateTime转换为从1970-01-01T00:00:00Z开始的秒数
            long curTimeSeconds = getCurTimeSeconds();
            prefs.putLong(LAST_LOGIN_SUCCESS_time_KEY, curTimeSeconds); 
        } else {
            Preferences prefs = Preferences.userNodeForPackage(getClass());
            // 清除保存的凭据
            prefs.remove(USERNAME_KEY);
            prefs.remove(PASSWORD_KEY);
            prefs.putBoolean(REMEMBER_ME_KEY, false);
        }
	}
	
	/**
	 * 实现自动登录功能，自动登录只能维持7天
	 */
	public void automatic_login() {
		if(automaticLogin.isSelected()) {
			 Preferences prefs = Preferences.userNodeForPackage(getClass());
	         prefs.putBoolean(Automatic_Login_KEY, true);
	         //记录登录时间
	         long curTimeSeconds = getCurTimeSeconds();
	         prefs.putLong(LAST_LOGIN_SUCCESS_time_KEY, curTimeSeconds); 
		}else {
			Preferences prefs = Preferences.userNodeForPackage(getClass());
	        prefs.putBoolean(Automatic_Login_KEY, false);
		}
	}
	

	
	//登录初始化,主要初始化自动登录和记住密码功能
	private void loadSavedCredentials() {
        Preferences prefs = Preferences.userNodeForPackage(getClass());
        long curTimeSeconds=getCurTimeSeconds();
        long lastTimeSeconds=prefs.getLong(LAST_LOGIN_SUCCESS_time_KEY, 0);
        //距离上次成功登录系统的时间
    	long Totaldays=(curTimeSeconds-lastTimeSeconds)/86400;
        //上一次选择了自动登录（选择自动登录一定会同时勾选记住密码）
        if(prefs.getBoolean(Automatic_Login_KEY, false)) {
        	//自动登录只能维持7天，7天后失效
            if(Totaldays<=7) {
            	automaticLogin.setSelected(true);
            	rememberMeCheckbox.setSelected(true);
                String username = prefs.get(USERNAME_KEY, "");
                String passWord = prefs.get(PASSWORD_KEY, "");
                userText.setText(username);
                password.setText(passWord);
                LoginActionListener autoLogin=new LoginActionListener();
                autoLogin.Login(1);
            }else {
            	clear_AL_RM();
            }
        }
        else if (prefs.getBoolean(REMEMBER_ME_KEY, false)) {      //只选了记住密码
        	//记住密码只能维持7天，7天后失效
            if(Totaldays<=7) {
            	rememberMeCheckbox.setSelected(true);
                String username = prefs.get(USERNAME_KEY, "");
                String passWord = prefs.get(PASSWORD_KEY, "");
                userText.setText(username);
                password.setText(passWord);
            }else {
            	clear_RM();
            }
        }else {
        	clear_AL_RM();
        }
    }
	
	
	//获取当前时间
	private long getCurTimeSeconds() {
		// 获取当前时间的LocalDateTime对象
        LocalDateTime now = LocalDateTime.now();
        // 获取当前时区偏移量
        ZoneOffset offset = ZoneOffset.systemDefault().getRules().getOffset(now);
        // 将LocalDateTime转换为从1970-01-01T00:00:00Z开始的秒数
        long epochSecond = now.toInstant(offset).getEpochSecond();
        return epochSecond;
	}
	
	//如果记住密码超过期限，或者上次没有选择记住密码但是登录成功，清除复选框和输入框内容
	private void clear_RM() {
		Preferences prefs = Preferences.userNodeForPackage(getClass());
		rememberMeCheckbox.setSelected(false);
        userText.setText("");
        password.setText("");
        //清除保存的凭据
        prefs.remove(USERNAME_KEY);
        prefs.remove(PASSWORD_KEY);
	}
	
	//自动登录和记住密码都没有勾选,或者自动登录超过期限
	private void clear_AL_RM() {
		clear_RM();
		Preferences prefs = Preferences.userNodeForPackage(getClass());
		automaticLogin.setSelected(false);
		prefs.putBoolean(Automatic_Login_KEY, false);
	}
	
	public void setAutomaticLoginKey(boolean auto_y_oy_n) {
		Preferences prefs = Preferences.userNodeForPackage(getClass());
		automaticLogin.setSelected(auto_y_oy_n);
		rememberMeCheckbox.setSelected(auto_y_oy_n);
		prefs.putBoolean(Automatic_Login_KEY, auto_y_oy_n);
		prefs.putBoolean(REMEMBER_ME_KEY, auto_y_oy_n);
    }
	
	
}

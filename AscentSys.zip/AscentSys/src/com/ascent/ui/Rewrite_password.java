package com.ascent.ui;
import java.util.Random;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JFrame;
import java.awt.event.MouseAdapter;  
import java.awt.event.MouseEvent; 
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.util.Arrays;


import com.ascent.util.UserDataClient;

public class Rewrite_password extends JFrame {
	protected JTextField userText;

	protected JPasswordField password;
	
	protected JPasswordField Confirm_pwd;
	
	protected JTextField phoneNumber;
	
	protected JTextField yzm;

	protected JLabel tip;

	protected UserDataClient userDataClient;
	
	protected JCheckBox rememberMeCheckbox;
	
	protected JPanel resetPanel;


	/**
	 * 默认构造方法，初始化用户注册窗体
	 */
	public Rewrite_password() {
		setTitle("重置密码");
		
 		
 		
// 		// 设置窗体无边框和标题栏
// 		setUndecorated(true);

 		// 设置布局和内容
 		getContentPane().setLayout(null);
 		resetPanel = new JPanel();
 		resetPanel.setLayout(null);
 		resetPanel.setOpaque(false); // 设置面板为不透明，以便背景图片可见
      
 		// ... 添加loginPanel中的组件 ...
 		
 		//标题
 		JLabel titleLabel = new JLabel("重置密码");
 		titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 30)); // 字体名称, 样式, 大小 
 		titleLabel.setBounds(210,60,350,30); 
 		
 		//用户名
 		JLabel userLabel = new JLabel("用户名：");
 		userLabel.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
 		userLabel.setBounds(135,164,80,20); 
 		userText = new JTextField(15);
		userText.setFont(new Font("微软雅黑", Font.PLAIN, 15)); // 字体名称, 样式, 大小 
		userText.setBorder(BorderFactory.createEmptyBorder(0,5,0,0));
		JScrollPane JSuserText=new JScrollPane(userText);
        // 永远不显示水平滚动条
		JSuserText.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		JSuserText.setBounds(200,160,200,30); 
		
        //新密码
 		JLabel passwordLabel = new JLabel("新密码：");
 		passwordLabel.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
 		passwordLabel.setBounds(135,214,80,20); 
		password = new JPasswordField(15);
		password.setBorder(BorderFactory.createEmptyBorder(0,5,0,0));
		password.setFont(new Font("微软雅黑", Font.PLAIN, 15)); // 字体名称, 样式, 大小 
		JScrollPane JSpassword=new JScrollPane(password);
		// 永远不显示水平滚动条
		JSpassword.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		JSpassword.setBounds(200,210,200,30); 
		
		//确认密码
		JLabel Confirm_password = new JLabel("确认密码：");
		Confirm_password.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
		Confirm_password.setBounds(120,264,80,20); 
		Confirm_pwd= new JPasswordField(15);
		Confirm_pwd.setBorder(BorderFactory.createEmptyBorder(0,5,0,0));
		Confirm_pwd.setFont(new Font("微软雅黑", Font.PLAIN, 15)); // 字体名称, 样式, 大小 
		JScrollPane JSConfirmPwd=new JScrollPane(Confirm_pwd);
		// 永远不显示水平滚动条
		JSConfirmPwd.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		JSConfirmPwd.setBounds(200,260,200,30); 
		
		//手机号
 		JLabel phoneLabel = new JLabel("手机号：");
 		phoneLabel.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
 		phoneLabel.setBounds(135,314,80,20); 
 		phoneNumber = new JTextField(15);
 		phoneNumber.setFont(new Font("微软雅黑", Font.PLAIN, 15)); // 字体名称, 样式, 大小 
 		phoneNumber.setBorder(BorderFactory.createEmptyBorder(0,5,0,0));
		JScrollPane JSphoneNumber=new JScrollPane(phoneNumber);
        // 永远不显示水平滚动条
		JSphoneNumber.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		JSphoneNumber.setBounds(200,310,200,30); 
		
		//验证码
 		JLabel yzmLabel = new JLabel("验证码：");
 		yzmLabel.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
 		yzmLabel.setBounds(135,364,80,20); 
 		yzm = new JTextField(15);
 		yzm.setFont(new Font("微软雅黑", Font.PLAIN, 15)); // 字体名称, 样式, 大小 
 		yzm.setBorder(BorderFactory.createEmptyBorder(0,5,0,0));
		JScrollPane JSyzm=new JScrollPane(yzm);
        // 永远不显示水平滚动条
		JSyzm.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		JSyzm.setBounds(200,360,120,30); 
		
		//发送验证码
		JButton sendYZMButton = new JButton("获取验证码");	
		sendYZMButton.setBorder(BorderFactory.createEmptyBorder());
		sendYZMButton.setBackground(new Color(72, 200, 255)); // 浅蓝色的一种可能的RGB值
		sendYZMButton.setForeground(Color.white);
		sendYZMButton.setFont(new Font("微软雅黑", Font.BOLD, 13)); // 字体名称, 样式, 大小 
		sendYZMButton.setBounds(320,359,80,30);
		sendYZMButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // 设置鼠标悬停时光标变为手形
		
		
		
        
       
		
	
		JButton saveButton = new JButton("保存");	
		saveButton.setBackground(new Color(72, 200, 255)); // 浅蓝色的一种可能的RGB值
		saveButton.setForeground(Color.white);
		saveButton.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
		saveButton.setBounds(190,435,70,30);
		saveButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // 设置鼠标悬停时光标变为手形
      
		JButton cancelButton = new JButton("取消");
		cancelButton.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
		cancelButton.setBackground(new Color(72, 200, 255)); // 浅蓝色的一种可能的RGB值
		cancelButton.setForeground(Color.white);
		cancelButton.setBounds(290,435,70,30);
		cancelButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // 设置鼠标悬停时光标变为手形
		
 
		
		resetPanel.add(Confirm_password);
		resetPanel.add(titleLabel);
		resetPanel.add(userLabel);
		resetPanel.add(JSuserText);
		resetPanel.add(passwordLabel);
		resetPanel.add(JSConfirmPwd);
		resetPanel.add(JSpassword);
		resetPanel.add(saveButton);
		resetPanel.add(cancelButton);
		resetPanel.add(phoneLabel);
		resetPanel.add(JSphoneNumber);
		resetPanel.add(JSyzm);
		resetPanel.add(yzmLabel);
		resetPanel.add(sendYZMButton);
		
		
		// 将loginPanel添加到内容面板，并设置其位置和大小  
		resetPanel.setBounds(0, 0, 550, 700); // 根据你的需求设置loginPanel的位置和大小  
		
        
        getContentPane().add(resetPanel);  
        getContentPane().setBackground(Color.white);
        
          
        saveButton.addActionListener(new SaveActionListener());
        cancelButton.addActionListener(new CancelActionListener());
        sendYZMButton.addActionListener(new SendYZMActionListener());
        Confirm_pwd.addFocusListener(new MyFocusListener());
       
		
		setSize(550, 700);    //窗体大小
        setLocationRelativeTo(null); // 居中显示窗口
        
        

		try {
			userDataClient = new UserDataClient();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 取消按钮事件监听
	 * @author ascent
	 */
	class CancelActionListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			setVisible(false);
			dispose();
		}
	}

	/**
	 * 保存按钮事件监听
	 * @author ascent
	 */
	class SaveActionListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			// 重置密码操作
			 // 获取新密码和确认密码  
	        char[] newPassword = password.getPassword();  
	        char[] confirmPassword = Confirm_pwd.getPassword();
	        
	        if(newPassword==null||newPassword.length==0) {
	        	JOptionPane.showMessageDialog(resetPanel,"密码不能为空！"); 
	        }else {
	        	  // 判断新密码和确认密码是否一致  
		        if (Arrays.equals(newPassword, confirmPassword)) {  
		            //密码一致，执行重置密码操作  
		            boolean success = userDataClient.resetPassword(userText.getText(), new String(newPassword));  
		            if (success) {  		          
		                JOptionPane.showMessageDialog(resetPanel,"密码重置成功！"); 
		            } else {  	          
		                JOptionPane.showMessageDialog(resetPanel,"密码重置失败，请检查用户名或联系管理员。"); 
		            }  
		        } else {  
		            // 密码不一致，给出提示    
		            JOptionPane.showMessageDialog(resetPanel,"新密码和确认密码不一致，请重新输入！");  
		        }  
		  
		        // 清除密码框内容，防止密码残留  
		        password.setText("");  
		        Confirm_pwd.setText("");  
	        }
	        
	      
		}
	}
	
	/**
	 * 发送验证码按钮事件监听
	 * @author ascent
	 */
	class SendYZMActionListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0) {
			String phoneNum =phoneNumber.getText();
			int len=phoneNum.length();
			if(len!=11) {
				JOptionPane.showMessageDialog(resetPanel,"请输入11位的手机号码！");  
			}else {
				// 生成六位数字的验证码
	            int code = generateRandomCode(6);
	            // 打印验证码，实际中这里应该是发送验证码的逻辑
	         
	            JOptionPane.showMessageDialog(resetPanel,"验证码："+code);  
	            // 这里可以添加发送验证码到手机的逻辑，例如调用短信服务API
//	            sendSMSToPhone(phoneNum, String.valueOf(code));
			}
			 
		}
	}
	
	// 生成指定长度的随机数字
    private int generateRandomCode(int length) {
        Random random = new Random();
        int code = 0;
        for (int i = 0; i < length; i++) {
            code = code * 10 + random.nextInt(10); // 生成0-9之间的随机数
        }
        return code;
    }



	/**
	 * 密码不一致触发的事件监听器处理类
	 * @author ascent
	 */
	class MyFocusListener implements FocusListener {

		public void focusGained(FocusEvent arg0) {
		}

		public void focusLost(FocusEvent e) { 
			if (e.getSource().equals(Confirm_pwd)) {  
	            char[] pwdChars = password.getPassword();  
	            char[] confirmChars = Confirm_pwd.getPassword();  
	            if (!Arrays.equals(pwdChars, confirmChars)) {  
	                JOptionPane.showMessageDialog(resetPanel, "两次密码不一致！");  
	            }
	        }  
		}
     }
}

package com.ascent.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.prefs.Preferences;
import com.ascent.bean.*;
import com.ascent.util.ProductDataClient;



/**
 * 艾斯医药主框架界面
 * @author ascent
 * @version 1.0
 */
@SuppressWarnings("serial")
public class MainFrame extends JFrame {

	/**
	 * tabbed pane组件
	 */
	protected JTabbedPane tabbedPane;

	/**
	 * 产品 panel
	 */
	protected ProductPanel productPanel;
	
    protected User mySelf;	
    
    protected ProductDataClient productDataClient;

	/**
	 * 默认构造方法
	 */
	public MainFrame(User user) {
        
		mySelf=user;
		
	
		setTitle("艾斯医药系统! ");

		Container container = this.getContentPane();
		
		container.setLayout(new BorderLayout());

		tabbedPane = new JTabbedPane();
	

		productPanel = new ProductPanel(this);
		tabbedPane.addTab("药品", productPanel);
		
		ProductPanel2 productPanel2 = new ProductPanel2(this);
		tabbedPane.addTab("订单", productPanel2);
		
		ProductPanel3 productPanel3 = new ProductPanel3(this);
		tabbedPane.addTab("查询", productPanel3);
		

		container.add(BorderLayout.CENTER, tabbedPane);
		

		JMenuBar myMenuBar = new JMenuBar();
	

		JMenu fileMenu = new JMenu("文件");   //第一行第一个
		
		JMenu openMenu = new JMenu("打开");
		JMenuItem localMenuItem = new JMenuItem("本地硬盘...");
		openMenu.add(localMenuItem);

		JMenuItem networkMenuItem = new JMenuItem("网络...");
		openMenu.add(networkMenuItem);

		JMenuItem webMenuItem = new JMenuItem("互联网...");
		openMenu.add(webMenuItem);
		
		fileMenu.add(openMenu);		

		JMenuItem saveMenuItem = new JMenuItem("保存");
		fileMenu.add(saveMenuItem);

		JMenuItem exitMenuItem = new JMenuItem("退出");
		fileMenu.add(exitMenuItem);
		
		myMenuBar.add(fileMenu);

		exitMenuItem.addActionListener(new ExitActionListener());

		setupLookAndFeelMenu(myMenuBar);   //设置选项

		JMenu helpMenu = new JMenu("帮助");     //第一行第三个
		JMenuItem aboutMenuItem = new JMenuItem("关于");
		helpMenu.add(aboutMenuItem);
		myMenuBar.add(helpMenu);
		
		JMenu MyInfoMenu = new JMenu("我的");     //第一行第四个
		JMenuItem BasicInfoMenuItem = new JMenuItem("基本信息");
		MyInfoMenu.add(BasicInfoMenuItem);
		
		JMenuItem LogoutMenuItem = new JMenuItem("退出登录");
		MyInfoMenu.add(LogoutMenuItem);
		
		myMenuBar.add(MyInfoMenu);
		
		
	
		
		
		
		LogoutMenuItem.addActionListener(new LogoutActionListener());
		aboutMenuItem.addActionListener(new AboutActionListener());
		BasicInfoMenuItem.addActionListener(new BasicInfoActionListener());

		this.setJMenuBar(myMenuBar);

		setSize(850, 550);
		setLocationRelativeTo(null); // 居中显示窗口

		this.addWindowListener(new WindowCloser());

		fileMenu.setMnemonic('f');
		exitMenuItem.setMnemonic('x');
		helpMenu.setMnemonic('h');
		aboutMenuItem.setMnemonic('a');

		// 设定快捷键
		exitMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X,
				ActionEvent.CTRL_MASK));

		saveMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,
				ActionEvent.CTRL_MASK));

		aboutMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A,
				ActionEvent.CTRL_MASK));
		
		
	}

	/**
	 * 设定和选择外观
	 */
	protected void setupLookAndFeelMenu(JMenuBar theMenuBar) {

		UIManager.LookAndFeelInfo[] lookAndFeelInfo = UIManager.getInstalledLookAndFeels();
		JMenu lookAndFeelMenu = new JMenu("选项");    //第一行第二个
		JMenuItem anItem = null;
		LookAndFeelListener myListener = new LookAndFeelListener();

		try {
			for (int i = 0; i < lookAndFeelInfo.length; i++) {
				anItem = new JMenuItem(lookAndFeelInfo[i].getName() + " 外观");
				anItem.setActionCommand(lookAndFeelInfo[i].getClassName());
				anItem.addActionListener(myListener);

				lookAndFeelMenu.add(anItem);
			}
			productDataClient = new ProductDataClient();
		} catch (Exception e) {
			e.printStackTrace();
		}
		theMenuBar.add(lookAndFeelMenu);
	}

	/**
	 * 退出方法.
	 */
	public void exit() {
		setVisible(false);
		dispose();
		System.exit(0);
	}

	/**
	 * "退出"事件处理内部类.
	 */
	class ExitActionListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			exit();
		}
	}

	/**
	 * 处理"关闭窗口"事件的内部类.
	 */
	class WindowCloser extends WindowAdapter {

		/**
		 * let's call our exit() method defined above
		 */
		public void windowClosing(WindowEvent e) {
			exit();
		}
	}

	/**
	 * 处理"外观"选择监听器的内部类
	 */
	class LookAndFeelListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			String className = event.getActionCommand();
			try {
				UIManager.setLookAndFeel(className);
				SwingUtilities.updateComponentTreeUI(MainFrame.this);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * 处理"关于"菜单监听器的内部类
	 */
	class AboutActionListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			String msg = "超值享受!";
			JOptionPane.showMessageDialog(MainFrame.this, msg);
		}
	}
	
	/**
	 * 处理"退出登录"菜单监听器的内部类
	 */
	class LogoutActionListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			// 弹出确认对话框
            int choice = JOptionPane.showConfirmDialog(
            		MainFrame.this, // 父组件，通常是当前窗口
                    "您确定要退出登录吗？", // 对话框消息
                    "退出登录确认", // 对话框标题
                    JOptionPane.YES_NO_OPTION, // 选项类型
                    JOptionPane.QUESTION_MESSAGE // 消息类型
            );

            // 根据用户的选择执行操作
            if (choice == JOptionPane.YES_OPTION) {
                // 用户选择了“是”，执行退出登录的逻辑
            	 setVisible(false);
                 dispose();
            	 LoginFrame myFrame = new LoginFrame(false);        	 
            	 myFrame.setVisible(true);
            	
            } else {
                // 用户选择了“否”，不执行任何操作
            }
		}
	}
	
	/**
	 * 处理"基本信息"菜单监听器的内部类
	 */
	class BasicInfoActionListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			//弹出个人基本信息框
			PersonInformation person=new PersonInformation(mySelf);
			person.setVisible(true);
		}
	}
	
	public void receiveMessage(boolean data) {
		
		if(data) {
			HashMap<String,ArrayList<Product>> map = productDataClient.getAllProducts();
			productPanel.populateListBox(map);
			
			
		}
		
	}
}
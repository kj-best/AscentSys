package com.ascent.ui;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Arrays;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import com.ascent.ui.RegistFrame.ExitActionListener;
import com.ascent.ui.RegistFrame.MyFocusListener;
import com.ascent.ui.RegistFrame.RegistActionListener;
import com.ascent.ui.RegistFrame.SendYZMActionListener;
import com.ascent.util.UserDataClient;
import javax.swing.JFrame;

import com.ascent.bean.*;
import com.ascent.util.ProductDataClient;

public class AddProducts extends JFrame {
	private JTextField productText;

	private JTextField CAS;

	private JTextField formula;
	
	private JTextField structure;
	
    protected JTextField Number;
    protected JTextField price;
    
    private static int addSuccess=0; 
	
    // 类别下拉框，创建一个新的JComboBox实例，并添加选项  
    JComboBox<String> comboBox = new JComboBox<>();  

	protected ProductDataClient productDataClient;
	
	private JPanel addProductsPanel;
	
	private MainFrame mainframe;
	
	
	/**
	 * 默认构造方法，初始化用户注册窗体
	 */
	public AddProducts(MainFrame mainframe) {
		
		this.mainframe=mainframe;
		
		setTitle("添加产品");

 		// 设置布局和内容
 		getContentPane().setLayout(null);
 		addProductsPanel = new JPanel();
 		addProductsPanel.setLayout(null);
 		
 		// ... 添加registPanel中的组件 ...
 		
 		//标题
 		JLabel titleLabel = new JLabel("新产品信息");
 		titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 30)); // 字体名称, 样式, 大小 
 		titleLabel.setBounds(350,60,300,30); 
 		
 		//用户名
 		JLabel productLabel = new JLabel("药品名称：");
 		productLabel.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
 		productLabel.setBounds(130,154,80,20); 
 		productText = new JTextField(15);
 		productText.setFont(new Font("微软雅黑", Font.PLAIN, 15)); // 字体名称, 样式, 大小 
 		productText.setBorder(BorderFactory.createEmptyBorder(0,5,0,0));
		JScrollPane JSproductText=new JScrollPane(productText);
        // 永远不显示水平滚动条
		JSproductText.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		JSproductText.setBounds(210,150,200,30); 
		
        //CAS
 		JLabel CASLabel = new JLabel("CAS号：");
 		CASLabel.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
 		CASLabel.setBounds(445,154,80,20); 
		CAS = new JTextField(15);
		CAS.setBorder(BorderFactory.createEmptyBorder(0,5,0,0));
		CAS.setFont(new Font("微软雅黑", Font.PLAIN, 15)); // 字体名称, 样式, 大小 
		JScrollPane JSCAS=new JScrollPane(CAS);
		// 永远不显示水平滚动条
		JSCAS.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		JSCAS.setBounds(510,150,200,30); 
		
		//结构图名称
		JLabel structureLabel = new JLabel("结构图名称：");
		structureLabel.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
		structureLabel.setBounds(115,204,150,20); 
		structure = new JTextField(15);
		structure.setBorder(BorderFactory.createEmptyBorder(0,5,0,0));
		structure.setFont(new Font("微软雅黑", Font.PLAIN, 15)); // 字体名称, 样式, 大小 
		JScrollPane JSstructure=new JScrollPane(structure);
		// 永远不显示水平滚动条
		JSstructure.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		JSstructure.setBounds(210,200,200,30); 
		
		//公式
		JLabel formulaLabel = new JLabel("公式：");
		formulaLabel.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
		formulaLabel.setBounds(460,204,80,20); 
		formula = new JTextField(15);
		formula.setBorder(BorderFactory.createEmptyBorder(0,5,0,0));
		formula.setFont(new Font("微软雅黑", Font.PLAIN, 15)); // 字体名称, 样式, 大小 
		JScrollPane JSformula=new JScrollPane(formula);
		// 永远不显示水平滚动条
		JSformula.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		JSformula.setBounds(510,200,200,30); 
		
		//数量
 		JLabel numLabel = new JLabel("数量：");
 		numLabel.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
 		numLabel.setBounds(160,254,80,20); 
 		Number = new JTextField(15);
 	    Number.setFont(new Font("微软雅黑", Font.PLAIN, 15)); // 字体名称, 样式, 大小 
 		Number.setBorder(BorderFactory.createEmptyBorder(0,5,0,0));
		JScrollPane JSNumber=new JScrollPane(Number);
        // 永远不显示水平滚动条
		JSNumber.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		JSNumber.setBounds(210,250,200,30); 
		
		//价格
 		JLabel priceLabel = new JLabel("价格：");
 		priceLabel.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
 		priceLabel.setBounds(460,254,80,20); 
 		price = new JTextField(15);
 		price.setFont(new Font("微软雅黑", Font.PLAIN, 15)); // 字体名称, 样式, 大小 
 		price.setBorder(BorderFactory.createEmptyBorder(0,5,0,0));
		JScrollPane JSprice=new JScrollPane(price);
        // 永远不显示水平滚动条
		JSprice.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		JSprice.setBounds(510,250,200,30); 
		
		//类别
 		JLabel categoryLabel = new JLabel("类别：");
 		categoryLabel.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
 		categoryLabel.setBounds(160,304,80,20); 
 		
 	    
        comboBox.setBorder(BorderFactory.createEmptyBorder(-2,-3,-2,-2));
        comboBox.setFont(new Font("微软雅黑", Font.PLAIN, 15));
        comboBox.addItem(" 保健药");
        comboBox.addItem(" 维生素");
        comboBox.addItem(" 生化药");  
        comboBox.addItem(" 西药");
        comboBox.setBounds(210,300,200,30);
		
		JButton completeButton = new JButton("完成");	
		completeButton.setBackground(new Color(72, 200, 255)); // 浅蓝色的一种可能的RGB值
		completeButton.setForeground(Color.white);
		completeButton.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
		completeButton.setBounds(340,380,70,30);
		completeButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // 设置鼠标悬停时光标变为手形
      
		JButton cancelButton = new JButton("取消");
		cancelButton.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
		cancelButton.setBackground(new Color(72, 200, 255)); // 浅蓝色的一种可能的RGB值
		cancelButton.setForeground(Color.white);
		cancelButton.setBounds(455,380,70,30);
		cancelButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // 设置鼠标悬停时光标变为手形
		
 
		
		addProductsPanel.add(formulaLabel);
		addProductsPanel.add(titleLabel);
		addProductsPanel.add(productLabel);
		addProductsPanel.add(JSproductText);
		addProductsPanel.add(CASLabel);
		addProductsPanel.add(JSformula);
		addProductsPanel.add(JSCAS);
		addProductsPanel.add(completeButton);
		addProductsPanel.add(cancelButton);
		addProductsPanel.add(numLabel);
		addProductsPanel.add(JSNumber);
		addProductsPanel.add(categoryLabel);
		addProductsPanel.add(comboBox);
		addProductsPanel.add(priceLabel);
		addProductsPanel.add(JSprice);
		addProductsPanel.add(structureLabel);
		addProductsPanel.add(JSstructure);
		
		
		// 将loginPanel添加到内容面板，并设置其位置和大小  
		addProductsPanel.setBounds(0, 0, 850, 550); // 根据你的需求设置loginPanel的位置和大小  
		addProductsPanel.setOpaque(false); // 设置面板为不透明，以便背景图片可见
        getContentPane().add(addProductsPanel); 
        getContentPane().setBackground(new Color(205,235,255));
         
        completeButton.addActionListener(new CompleteActionListener());
        cancelButton.addActionListener(new ExitActionListener());
		
		setSize(850, 550);    //窗体大小
        setLocation(400,180); // 居中显示窗口
        
		try {
			productDataClient = new ProductDataClient();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 取消按钮事件监听
	 * @author ascent
	 */
	class ExitActionListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			setVisible(false);
			dispose();
		}
	}
	
	/**
	 * 完成按钮事件监听
	 * @author ascent
	 */
	class CompleteActionListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			// 添加产品操作
			String productName=productText.getText();
			String cas=CAS.getText();
			String formu=formula.getText();
			String num=Number.getText();
			String pric=price.getText();
			String category=comboBox.getSelectedItem().toString();
			String struc=structure.getText();
			
			
			if(productName.length()==0) {
				 JOptionPane.showMessageDialog(addProductsPanel, "请输入药品名！");  
			}
			else if(cas.length()==0) {
				 JOptionPane.showMessageDialog(addProductsPanel, "请输入CAS号！");  
			}
			else if(formu.length()==0) {
				JOptionPane.showMessageDialog(addProductsPanel, "请输入公式！");  
			}
			else if(struc.length()==0) {
				JOptionPane.showMessageDialog(addProductsPanel, "请输入结构图名称！");  
			}
			else if(num.length()==0){
				JOptionPane.showMessageDialog(addProductsPanel, "请输入数量！");  
			}
			else if(pric.length()==0){
				JOptionPane.showMessageDialog(addProductsPanel, "请输入价格！");  
			}
			else {
				Product product=new Product();
				product.setCas(cas);
				product.setCategory(category);
				product.setFormula(formu);
				product.setPrice(pric);
				product.setProductname(productName);
				product.setRealstock(num);
				product.setStructure(struc);
				
				boolean bo = productDataClient.addProduct(product);
				if (bo) {
					mainframe.receiveMessage(true);
					JOptionPane.showMessageDialog(addProductsPanel, "添加新品成功！");  		    
					
				} else {
					mainframe.receiveMessage(false);
					JOptionPane.showMessageDialog(addProductsPanel, "添加新品失败！新品已存在！");  
					
				}
			}
		}
	}

}

package com.ascent.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;
import java.io.IOException;
import java.util.Arrays;
import java.util.Random;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import com.ascent.ui.Rewrite_password.CancelActionListener;
import com.ascent.ui.Rewrite_password.MyFocusListener;
import com.ascent.ui.Rewrite_password.SaveActionListener;
import com.ascent.ui.Rewrite_password.SendYZMActionListener;
import com.ascent.util.UserDataClient;

import com.ascent.bean.*;


/**
 * 用户注册窗体
 * @author ascent
 * @version 1.0
 */
@SuppressWarnings("serial")
public class RegistFrame extends JFrame {
	private JTextField userText;

	private JPasswordField password;

	private JPasswordField repassword;
	
    protected JTextField phoneNumber;
	
	protected JTextField yzm;
	
	protected String yzmCode="";

	private JLabel tip;

	private UserDataClient userDataClient;
	
	private JPanel registPanel;
	/**
	 * 默认构造方法，初始化用户注册窗体
	 */
	public RegistFrame() {
		setTitle("用户注册");

 		// 设置布局和内容
 		getContentPane().setLayout(null);
 		registPanel = new JPanel();
 		registPanel.setLayout(null);
 		
 		// ... 添加registPanel中的组件 ...
 		
 		//标题
 		JLabel titleLabel = new JLabel("用户注册");
 		titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 30)); // 字体名称, 样式, 大小 
 		titleLabel.setBounds(210,60,350,30); 
 		
 		//用户名
 		JLabel userLabel = new JLabel("用户名：");
 		userLabel.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
 		userLabel.setBounds(135,164,80,20); 
 		userText = new JTextField(15);
		userText.setFont(new Font("微软雅黑", Font.PLAIN, 15)); // 字体名称, 样式, 大小 
		userText.setBorder(BorderFactory.createEmptyBorder(0,5,0,0));
		JScrollPane JSuserText=new JScrollPane(userText);
        // 永远不显示水平滚动条
		JSuserText.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		JSuserText.setBounds(200,160,200,30); 
		
        //密码
 		JLabel passwordLabel = new JLabel("密码：");
 		passwordLabel.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
 		passwordLabel.setBounds(135,214,80,20); 
		password = new JPasswordField(15);
		password.setBorder(BorderFactory.createEmptyBorder(0,5,0,0));
		password.setFont(new Font("微软雅黑", Font.PLAIN, 15)); // 字体名称, 样式, 大小 
		JScrollPane JSpassword=new JScrollPane(password);
		// 永远不显示水平滚动条
		JSpassword.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		JSpassword.setBounds(200,210,200,30); 
		
		//重复密码
		JLabel repasswordLabel = new JLabel("重复密码：");
		repasswordLabel.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
		repasswordLabel.setBounds(120,264,80,20); 
		repassword = new JPasswordField(15);
		repassword.setBorder(BorderFactory.createEmptyBorder(0,5,0,0));
		repassword.setFont(new Font("微软雅黑", Font.PLAIN, 15)); // 字体名称, 样式, 大小 
		JScrollPane JSRepassword=new JScrollPane(repassword);
		// 永远不显示水平滚动条
		JSRepassword.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		JSRepassword.setBounds(200,260,200,30); 
		
		//手机号
 		JLabel phoneLabel = new JLabel("手机号：");
 		phoneLabel.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
 		phoneLabel.setBounds(135,314,80,20); 
 		phoneNumber = new JTextField(15);
 		phoneNumber.setFont(new Font("微软雅黑", Font.PLAIN, 15)); // 字体名称, 样式, 大小 
 		phoneNumber.setBorder(BorderFactory.createEmptyBorder(0,5,0,0));
		JScrollPane JSphoneNumber=new JScrollPane(phoneNumber);
        // 永远不显示水平滚动条
		JSphoneNumber.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		JSphoneNumber.setBounds(200,310,200,30); 
		
		//验证码
 		JLabel yzmLabel = new JLabel("验证码：");
 		yzmLabel.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
 		yzmLabel.setBounds(135,364,80,20); 
 		yzm = new JTextField(15);
 		yzm.setFont(new Font("微软雅黑", Font.PLAIN, 15)); // 字体名称, 样式, 大小 
 		yzm.setBorder(BorderFactory.createEmptyBorder(0,5,0,0));
		JScrollPane JSyzm=new JScrollPane(yzm);
        // 永远不显示水平滚动条
		JSyzm.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		JSyzm.setBounds(200,360,120,30); 
		
		//发送验证码
		JButton sendYZMButton = new JButton("获取验证码");	
		sendYZMButton.setBorder(BorderFactory.createEmptyBorder());
		sendYZMButton.setBackground(new Color(72, 200, 255)); // 浅蓝色的一种可能的RGB值
		sendYZMButton.setForeground(Color.white);
		sendYZMButton.setFont(new Font("微软雅黑", Font.BOLD, 13)); // 字体名称, 样式, 大小 
		sendYZMButton.setBounds(320,359,80,30);
		sendYZMButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // 设置鼠标悬停时光标变为手形
		
		JButton RegistButton = new JButton("注册");	
		RegistButton.setBackground(new Color(72, 200, 255)); // 浅蓝色的一种可能的RGB值
		RegistButton.setForeground(Color.white);
		RegistButton.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
		RegistButton.setBounds(190,435,70,30);
		RegistButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // 设置鼠标悬停时光标变为手形
      
		JButton cancelButton = new JButton("取消");
		cancelButton.setFont(new Font("微软雅黑", Font.BOLD, 15)); // 字体名称, 样式, 大小 
		cancelButton.setBackground(new Color(72, 200, 255)); // 浅蓝色的一种可能的RGB值
		cancelButton.setForeground(Color.white);
		cancelButton.setBounds(290,435,70,30);
		cancelButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // 设置鼠标悬停时光标变为手形
		
 
		
		registPanel.add(repasswordLabel);
		registPanel.add(titleLabel);
		registPanel.add(userLabel);
		registPanel.add(JSuserText);
		registPanel.add(passwordLabel);
		registPanel.add(JSRepassword);
		registPanel.add(JSpassword);
		registPanel.add(RegistButton);
		registPanel.add(cancelButton);
		registPanel.add(phoneLabel);
		registPanel.add(JSphoneNumber);
		registPanel.add(JSyzm);
		registPanel.add(yzmLabel);
		registPanel.add(sendYZMButton);
		
		
		// 将loginPanel添加到内容面板，并设置其位置和大小  
		registPanel.setBounds(0, 0, 550, 700); // 根据你的需求设置loginPanel的位置和大小  
		registPanel.setOpaque(false); // 设置面板为不透明，以便背景图片可见
        getContentPane().add(registPanel); 
        getContentPane().setBackground(Color.white);
         
        RegistButton.addActionListener(new RegistActionListener());
        cancelButton.addActionListener(new ExitActionListener());
        sendYZMButton.addActionListener(new SendYZMActionListener());
        repassword.addFocusListener(new MyFocusListener());
       
		
		setSize(550, 700);    //窗体大小
        setLocationRelativeTo(null); // 居中显示窗口
        
        

		try {
			userDataClient = new UserDataClient();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 取消按钮事件监听
	 * @author ascent
	 */
	class ExitActionListener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			setVisible(false);
			dispose();
		}
	}

	/**
	 * 注册按钮事件监听
	 * @author ascent
	 */
	class RegistActionListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			// 用户注册操作
			String userName=userText.getText();
			String phoneNum=phoneNumber.getText();
			String YZM=yzm.getText();
			char[] passWord=password.getPassword();
			char[] repassWord=repassword.getPassword();
			
			
			if(userName.length()==0) {
				 JOptionPane.showMessageDialog(registPanel, "请输入用户名！");  
			}
			else if(passWord.length==0) {
				 JOptionPane.showMessageDialog(registPanel, "请输入密码！");  
			}
			else if(repassWord.length==0) {
				JOptionPane.showMessageDialog(registPanel, "重复密码不能为空！");  
			}else if(phoneNum.length()!=11){
				JOptionPane.showMessageDialog(registPanel, "请输入11位数字的手机号！");  
			}
			else if(YZM.length()!=6){
				JOptionPane.showMessageDialog(registPanel, "请输入6位数字的验证码！");  
			}
			else if(!Arrays.equals(passWord, repassWord)) {
				JOptionPane.showMessageDialog(registPanel, "注册失败！两次密码不一致！");  
			}else if(!yzmCode.equals(YZM)) {
				JOptionPane.showMessageDialog(registPanel, "错误的验证码！请重新输入！");  
			}
			else {
				
				boolean bo = userDataClient.addUser(userText.getText(), new String(password.getPassword()));
				if (bo) {
					JOptionPane.showMessageDialog(registPanel, "恭喜你！注册成功！");  
				} else {
					JOptionPane.showMessageDialog(registPanel, "注册失败！用户名已存在！");  
				}
			}
			
		}
	}

	/**
	 * "关闭窗口"事件处理内部类
	 * @author ascent
	 */
	class WindowCloser extends WindowAdapter {
		public void windowClosing(WindowEvent e) {
			setVisible(false);
			dispose();
		}
	}

	/**
	 * 密码不一致触发的事件监听器处理类
	 * @author ascent
	 */
	class MyFocusListener implements FocusListener {

		public void focusGained(FocusEvent arg0) {
		}

		public void focusLost(FocusEvent e) {
			if (e.getSource().equals(repassword)) {
				if (!new String(password.getPassword()).equals(new String(repassword.getPassword()))) {
					JOptionPane.showMessageDialog(registPanel, "两次密码不一致！");  
				}
			} 
		}
	}
	
	/**
	 * 发送验证码按钮事件监听
	 * @author ascent
	 */
	class SendYZMActionListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0) {
			String phoneNum =phoneNumber.getText();
			int len=phoneNum.length();
			if(len!=11) {
				JOptionPane.showMessageDialog(registPanel,"请输入11位的手机号码！");  
			}else {
				// 生成六位数字的验证码
	            yzmCode = String.valueOf(generateRandomCode(6));
	            // 打印验证码，实际中这里应该是发送验证码的逻辑
	         
	            JOptionPane.showMessageDialog(registPanel,"验证码："+yzmCode);  
	            // 这里可以添加发送验证码到手机的逻辑，例如调用短信服务API
//	            sendSMSToPhone(phoneNum, String.valueOf(code));
			}
			 
		}
	}
	
	// 生成指定长度的随机数字
    private int generateRandomCode(int length) {
        Random random = new Random();
        int code = 0;
        for (int i = 0; i < length; i++) {
            code = code * 10 + random.nextInt(10); // 生成0-9之间的随机数
        }
        return code;
    }
}
